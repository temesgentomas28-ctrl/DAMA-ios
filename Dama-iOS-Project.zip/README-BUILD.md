Dama iOS build preparation

This folder contains the Swift sources plus a generated Xcode project and a GitHub Actions workflow.

Important:
- The workflow creates an UNSIGNED IPA artifact.
- An unsigned IPA is not normally installable on an iPhone by itself.
- A signed build requires Apple code signing/provisioning appropriate to the installation method.
