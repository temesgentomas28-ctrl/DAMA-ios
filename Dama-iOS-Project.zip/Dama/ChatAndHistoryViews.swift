import SwiftUI
import SwiftData

struct ChatView: View {
    @EnvironmentObject var a: Assistant
    let conversation: Conversation
    @State private var input = ""

    private var msgs: [ChatMessage] { conversation.messages.sorted { $0.createdAt < $1.createdAt } }

    var body: some View {
        VStack(spacing: 0) {
            ScrollViewReader { proxy in
                ScrollView {
                    LazyVStack(spacing: 10) {
                        ForEach(msgs) { m in
                            HStack {
                                if m.role == "user" { Spacer(minLength: 40) }
                                Text(m.text).textSelection(.enabled)
                                    .padding(12)
                                    .background(m.role == "user" ? Color.cyan.opacity(0.2) : Color.white.opacity(0.08),
                                                in: RoundedRectangle(cornerRadius: 16))
                                if m.role != "user" { Spacer(minLength: 40) }
                            }
                            .id(m.id)
                        }
                        if a.state == .thinking { ProgressView().padding() }
                    }
                    .padding()
                }
                .onChange(of: msgs.count) { _, _ in
                    withAnimation { proxy.scrollTo(msgs.last?.id, anchor: .bottom) }
                }
            }
            HStack(alignment: .bottom) {
                TextField("Nachricht an Dama", text: $input, axis: .vertical)
                    .lineLimit(1...5).padding(10)
                    .background(.white.opacity(0.08), in: RoundedRectangle(cornerRadius: 18))
                Button {
                    let t = input; input = ""
                    a.open(conversation)
                    Task { await a.send(t) }
                } label: { Image(systemName: "arrow.up.circle.fill").font(.system(size: 34)) }
                .disabled(input.trimmingCharacters(in: .whitespaces).isEmpty || a.state == .thinking)
            }
            .padding()
        }
        .background(DamaBackground())
        .navigationTitle(conversation.title)
        .navigationBarTitleDisplayMode(.inline)
    }
}

struct HistoryView: View {
    @Environment(\.modelContext) private var ctx
    @EnvironmentObject var a: Assistant
    @Query(sort: \Conversation.createdAt, order: .reverse) private var convos: [Conversation]
    @State private var confirmAll = false

    private var groups: [(day: Date, items: [Conversation])] {
        let g = Dictionary(grouping: convos) { Calendar.current.startOfDay(for: $0.createdAt) }
        return g.keys.sorted(by: >).map { ($0, g[$0] ?? []) }
    }

    var body: some View {
        NavigationStack {
            List {
                ForEach(groups, id: \.day) { grp in
                    Section(grp.day.formatted(date: .complete, time: .omitted)) {
                        ForEach(grp.items) { c in
                            NavigationLink { ChatView(conversation: c) } label: {
                                VStack(alignment: .leading, spacing: 2) {
                                    Text(c.title).lineLimit(1)
                                    Text("\(c.messages.count) Nachrichten").font(.caption).foregroundStyle(.secondary)
                                }
                            }
                        }
                        .onDelete { idx in
                            for i in idx {
                                if a.current?.id == grp.items[i].id { a.current = nil }
                                ctx.delete(grp.items[i])
                            }
                            try? ctx.save()
                        }
                    }
                }
            }
            .overlay {
                if convos.isEmpty {
                    ContentUnavailableView("Noch keine Gespräche", systemImage: "bubble.left.and.bubble.right")
                }
            }
            .navigationTitle("Verlauf")
            .toolbar {
                if !convos.isEmpty {
                    Button("Alle löschen", role: .destructive) { confirmAll = true }
                }
            }
            .confirmationDialog("Alle Gespräche löschen?", isPresented: $confirmAll, titleVisibility: .visible) {
                Button("Alle löschen", role: .destructive) {
                    convos.forEach { ctx.delete($0) }; try? ctx.save(); a.current = nil
                }
            }
        }
    }
}
