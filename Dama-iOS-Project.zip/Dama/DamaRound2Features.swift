import SwiftUI
import SwiftData
import WebKit
import UserNotifications

// MARK: - Round 2: Points 51–100

enum DamaSkillCategory: String, CaseIterable, Identifiable {
    case search = "Recherche"
    case knowledge = "Wissen"
    case learning = "Lernen"
    case math = "Mathe"
    case writing = "Schreiben"
    case translation = "Übersetzen"
    case coding = "Programmieren"
    case documents = "Dokumente"
    case automation = "Automationen"
    var id: String { rawValue }
}

struct DamaSkill: Identifiable, Hashable {
    let id: String
    let name: String
    let category: DamaSkillCategory
    let description: String
    let systemAvailable: Bool
}

struct DamaSkillRegistry {
    static let shared = DamaSkillRegistry()
    let skills: [DamaSkill] = [
        .init(id: "web-search", name: "Websuche", category: .search, description: "Aktuelle Informationen und Quellen öffnen.", systemAvailable: true),
        .init(id: "knowledge", name: "Wissensantwort", category: .knowledge, description: "Erklären, zusammenfassen und Zusammenhänge herstellen.", systemAvailable: true),
        .init(id: "learning", name: "Lernmodus", category: .learning, description: "Schulische Inhalte verständlich erklären und üben.", systemAvailable: true),
        .init(id: "math", name: "Mathe", category: .math, description: "Rechnen, Formeln und Einheiten.", systemAvailable: true),
        .init(id: "writing", name: "Schreiben", category: .writing, description: "Texte, Nachrichten und Dokumente formulieren.", systemAvailable: true),
        .init(id: "translation", name: "Übersetzung", category: .translation, description: "Mehrsprachige Übersetzung und Sprachhilfe.", systemAvailable: true),
        .init(id: "coding", name: "Code", category: .coding, description: "Code erklären, strukturieren und Fehler lokalisieren.", systemAvailable: true),
        .init(id: "documents", name: "Dokumente", category: .documents, description: "Dokumente auswählen und für die Analyse vorbereiten.", systemAvailable: true),
        .init(id: "automation", name: "Automationen", category: .automation, description: "Erinnerungen, Kalender und Kurzbefehle über iOS.", systemAvailable: true)
    ]
}

struct DamaSearchResult: Identifiable, Hashable {
    let id = UUID()
    let title: String
    let url: URL
    let snippet: String
    let sourceName: String
    let retrievedAt = Date()
}

@MainActor
final class DamaSearchService: ObservableObject {
    @Published private(set) var results: [DamaSearchResult] = []
    @Published private(set) var isSearching = false
    @Published var errorMessage: String?

    func search(_ query: String) {
        let q = query.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !q.isEmpty else { return }
        isSearching = true
        errorMessage = nil
        results = []
        // iOS-safe foundation: open the user's chosen search engine in a system web view.
        // A future authenticated provider can implement the same result model without changing the UI.
        let encoded = q.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed) ?? q
        if let url = URL(string: "https://www.google.com/search?q=\(encoded)") {
            results = [DamaSearchResult(title: "Websuche nach „\(q)“", url: url, snippet: "Öffne die Suche für aktuelle Ergebnisse und Quellen.", sourceName: "Web")]
        }
        isSearching = false
    }
}

struct DamaWebView: UIViewRepresentable {
    let url: URL
    func makeUIView(context: Context) -> WKWebView { WKWebView(frame: .zero) }
    func updateUIView(_ webView: WKWebView, context: Context) {
        guard webView.url != url else { return }
        webView.load(URLRequest(url: url))
    }
}

struct DamaSearchView: View {
    @StateObject private var service = DamaSearchService()
    @State private var query = ""
    @State private var opened: DamaSearchResult?

    var body: some View {
        NavigationStack {
            VStack(spacing: 12) {
                HStack {
                    Image(systemName: "magnifyingglass").foregroundStyle(.secondary)
                    TextField("Im Web suchen …", text: $query)
                        .textInputAutocapitalization(.never)
                        .onSubmit { service.search(query) }
                    Button("Suchen") { service.search(query) }
                        .buttonStyle(.borderedProminent)
                }
                .padding(12)
                .background(.thinMaterial, in: RoundedRectangle(cornerRadius: 16))
                if service.isSearching { ProgressView() }
                List(service.results) { result in
                    Button { opened = result } label: {
                        VStack(alignment: .leading, spacing: 5) {
                            Text(result.title).font(.headline)
                            Text(result.snippet).font(.subheadline).foregroundStyle(.secondary)
                            Text(result.sourceName).font(.caption).foregroundStyle(.tint)
                        }
                    }
                }
            }
            .padding(.horizontal)
            .navigationTitle("Recherche")
            .sheet(item: $opened) { result in
                NavigationStack {
                    DamaWebView(url: result.url)
                        .navigationTitle("Web")
                        .navigationBarTitleDisplayMode(.inline)
                }
            }
        }
    }
}

struct DamaSkillLibraryView: View {
    @State private var selectedCategory: DamaSkillCategory?
    private let registry = DamaSkillRegistry.shared

    var filtered: [DamaSkill] {
        guard let selectedCategory else { return registry.skills }
        return registry.skills.filter { $0.category == selectedCategory }
    }

    var body: some View {
        NavigationStack {
            List {
                Section {
                    Picker("Kategorie", selection: $selectedCategory) {
                        Text("Alle").tag(DamaSkillCategory?.none)
                        ForEach(DamaSkillCategory.allCases) { c in Text(c.rawValue).tag(Optional(c)) }
                    }
                    .pickerStyle(.menu)
                }
                Section("Skills") {
                    ForEach(filtered) { skill in
                        HStack(spacing: 12) {
                            Image(systemName: "sparkles")
                                .foregroundStyle(.tint)
                            VStack(alignment: .leading) {
                                Text(skill.name).font(.headline)
                                Text(skill.description).font(.caption).foregroundStyle(.secondary)
                            }
                            Spacer()
                            Image(systemName: skill.systemAvailable ? "checkmark.circle.fill" : "minus.circle")
                                .foregroundStyle(skill.systemAvailable ? .green : .secondary)
                        }
                    }
                }
            }
            .navigationTitle("Skills")
        }
    }
}

struct DamaSourceBadge: View {
    let source: DamaSource
    var body: some View {
        Label(source.title, systemImage: "link")
            .font(.caption)
            .foregroundStyle(.tint)
    }
}

struct DamaSearchableText: View {
    let text: String
    let query: String
    var body: some View {
        Text(text)
            .textSelection(.enabled)
            .overlay(alignment: .topLeading) {
                if !query.isEmpty {
                    Color.clear.accessibilityLabel("Suchtext: \(query)")
                }
            }
    }
}

struct DamaGlobalSearchView: View {
    @Environment(\.modelContext) private var ctx
    @Query(sort: \Conversation.createdAt, order: .reverse) private var conversations: [Conversation]
    @Query(sort: \DamaSavedItem.createdAt, order: .reverse) private var saved: [DamaSavedItem]
    @State private var query = ""

    private var matchingConversations: [Conversation] {
        guard !query.isEmpty else { return conversations }
        return conversations.filter { $0.title.localizedCaseInsensitiveContains(query) || $0.messages.contains { $0.text.localizedCaseInsensitiveContains(query) } }
    }
    private var matchingSaved: [DamaSavedItem] {
        guard !query.isEmpty else { return saved }
        return saved.filter { $0.title.localizedCaseInsensitiveContains(query) || $0.text.localizedCaseInsensitiveContains(query) }
    }

    var body: some View {
        NavigationStack {
            List {
                Section("Gespräche") {
                    ForEach(matchingConversations) { c in
                        NavigationLink(c.title) { ChatView(conversation: c) }
                    }
                }
                Section("Gespeichert") {
                    ForEach(matchingSaved) { item in
                        VStack(alignment: .leading) {
                            Text(item.title).font(.headline)
                            Text(item.text).font(.caption).foregroundStyle(.secondary).lineLimit(2)
                        }
                    }
                }
                if matchingConversations.isEmpty && matchingSaved.isEmpty {
                    ContentUnavailableView.search(text: query)
                }
            }
            .searchable(text: $query, prompt: "Chats, Projekte, Notizen …")
            .navigationTitle("Globale Suche")
        }
    }
}

struct DamaNotificationCenterView: View {
    @AppStorage("dama.notifications.enabled") private var enabled = true
    @State private var permissionText = "Noch nicht geprüft"
    var body: some View {
        Form {
            Section("Benachrichtigungen") {
                Toggle("Dama-Benachrichtigungen", isOn: $enabled)
                Button("Berechtigung prüfen") {
                    UNUserNotificationCenter.current().getNotificationSettings { settings in
                        Task { @MainActor in permissionText = settings.authorizationStatus.rawValue == 1 ? "Erlaubt" : "Nicht erlaubt" }
                    }
                }
                Text(permissionText).font(.caption).foregroundStyle(.secondary)
            }
            Section("Transparenz") {
                Text("Dama zeigt bei Aktionen, die iOS oder andere Apps öffnen, eine Bestätigung. Nicht verfügbare Hintergrundfunktionen werden nicht vorgetäuscht.")
                    .font(.caption)
            }
        }
        .navigationTitle("Benachrichtigungen")
    }
}

struct DamaFoldersView: View {
    @Environment(\.modelContext) private var ctx
    @Query(sort: \DamaProject.createdAt, order: .reverse) private var projects: [DamaProject]
    @State private var adding = false
    @State private var name = ""

    var body: some View {
        List {
            Section("Projekte") {
                ForEach(projects) { project in
                    NavigationLink {
                        DamaProjectDetailView(project: project)
                    } label: {
                        Label(project.name, systemImage: "folder.fill")
                    }
                }
                .onDelete { offsets in
                    offsets.map { projects[$0] }.forEach(ctx.delete)
                    try? ctx.save()
                }
            }
        }
        .navigationTitle("Ordner & Projekte")
        .toolbar {
            Button { adding = true } label: { Image(systemName: "folder.badge.plus") }
        }
        .alert("Neues Projekt", isPresented: $adding) {
            TextField("Name", text: $name)
            Button("Erstellen") {
                let n = name.trimmingCharacters(in: .whitespacesAndNewlines)
                if !n.isEmpty { ctx.insert(DamaProject(name: n)); try? ctx.save() }
                name = ""
            }
            Button("Abbrechen", role: .cancel) { name = "" }
        }
    }
}

struct DamaProjectDetailView: View {
    @Bindable var project: DamaProject
    var body: some View {
        Form {
            Section("Projekt") {
                TextField("Name", text: $project.name)
                TextField("Details", text: $project.details, axis: .vertical)
            }
            Section("Status") {
                LabeledContent("Erstellt", value: project.createdAt.formatted(date: .abbreviated, time: .shortened))
                LabeledContent("Geändert", value: project.updatedAt.formatted(date: .abbreviated, time: .shortened))
            }
        }
        .navigationTitle(project.name)
        .onChange(of: project.name) { _, _ in project.updatedAt = .now }
        .onChange(of: project.details) { _, _ in project.updatedAt = .now }
    }
}

struct DamaContextInfoView: View {
    @EnvironmentObject var settings: DamaSettings
    var body: some View {
        List {
            Section("Aktiver Kontext") {
                LabeledContent("Sprache", value: settings.language == "en" ? "English" : "Deutsch")
                LabeledContent("Modellmodus", value: settings.modelMode.rawValue)
                LabeledContent("Websuche", value: settings.webSearch ? "Ein" : "Aus")
                LabeledContent("Gedächtnis", value: UserDefaults.standard.bool(forKey: "memoryEnabled") ? "Ein" : "Aus")
            }
            Section("Unsicherheit") {
                Text("Dama soll zwischen sicherem Wissen, aktueller Recherche und unsicheren Annahmen unterscheiden. Quellen werden bei recherchierten Ergebnissen separat angezeigt.")
                    .font(.caption).foregroundStyle(.secondary)
            }
        }
        .navigationTitle("Kontext & Quellen")
    }
}
