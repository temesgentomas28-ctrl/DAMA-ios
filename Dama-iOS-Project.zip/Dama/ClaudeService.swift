import Foundation
import SwiftData

struct ToolDef {
    let name: String
    let description: String
    let schema: [String: Any]
}

enum ClaudeError: LocalizedError {
    case noKey, http(Int), badResponse
    var errorDescription: String? {
        switch self {
        case .noKey: return "Bitte hinterlege zuerst deinen Anthropic-API-Schlüssel in den Einstellungen."
        case .http(let c) where c == 401: return "Der API-Schlüssel wurde abgelehnt. Bitte prüfe ihn in den Einstellungen."
        case .http(let c): return "Verbindungsproblem (Code \(c)). Bitte versuche es gleich noch einmal."
        case .badResponse: return "Ich habe eine unverständliche Antwort vom Server erhalten."
        }
    }
}

enum Prompt {
    static func system(memories: [String]) -> String {
        let now = Date().formatted(date: .complete, time: .shortened)
        let tz = TimeZone.current.identifier
        let mem = memories.isEmpty ? "(noch nichts gespeichert)" : memories.map { "- \($0)" }.joined(separator: "\n")
        return """
        Du bist Dama, der persönliche digitale Assistent deines Nutzers – kein gewöhnlicher Chatbot. \
        Du sprichst ruhig, höflich, respektvoll und direkt mit dem Nutzer (Du-Form), beleidigst nie und drängst keine ungefragten Meinungen auf. \
        Fragt der Nutzer ausdrücklich nach deiner ehrlichen Einschätzung, antwortest du ehrlich, direkt und respektvoll.

        Arbeitsweise:
        - Antworte in der Sprache des Nutzers (Deutsch oder Englisch). Deine Antworten werden vorgelesen: kurz, natürlich, KEIN Markdown, keine Aufzählungszeichen, keine URLs vorlesen.
        - Führe Anweisungen aus, statt zu diskutieren oder zu bevormunden. Plane bei Aufgaben zuerst die nötigen Schritte und nutze deine Werkzeuge selbstständig. Stelle keine Fragen, deren Antwort du schon kennst (siehe Erinnerungen und Gesprächsverlauf).
        - Kann etwas technisch, rechtlich oder ethisch nicht ausgeführt werden, sage kurz und klar warum und biete die nächstbeste Lösung an.
        - Bei aktuellen, sich ändernden oder dir unbekannten Themen (Nachrichten, Spiele wie Fortnite, Updates, Technik, Apps, Trends, Wetter, Sport, Filme, Serien, Personen) nutzt du IMMER web_search, vergleichst mehrere Quellen und nennst die neuesten verfügbaren Informationen. Sage nicht einfach „Ich weiß es nicht“, sondern recherchiere.
        - Erfinde niemals Informationen. Wenn du etwas nicht zuverlässig herausfinden kannst, sage das ehrlich und erkläre kurz, was du geprüft hast.
        - Speichere mit save_memory nur dauerhaft wichtige Informationen über den Nutzer, wenn er dich darum bittet oder es eindeutig nützlich und harmlos ist (Vorlieben, Namen, Gewohnheiten). Nie Passwörter oder Zahlungsdaten.
        - Sensible oder nicht rückgängig machbare Aktionen (Käufe, Löschen, Anrufe, Nachrichten versenden) bestätigt die App vor der Ausführung beim Nutzer. Erkläre vorher kurz, was du tun willst.
        - Eigene Befehle des Nutzers (z. B. „starte meinen Abend“) führst du über run_shortcut aus, falls ein passender iOS-Kurzbefehl existiert.

        Aktuelles Datum und Uhrzeit: \(now) (Zeitzone \(tz)). Verwende für Zeitangaben in Werkzeugen ISO-8601 (z. B. 2026-11-09T18:30:00+01:00).

        Das weißt du über den Nutzer:
        \(mem)
        """
    }
}

final class ClaudeService {
    static let model = "claude-sonnet-5-5"

    func chat(history: [(role: String, text: String)],
              system: String,
              tools: [ToolDef],
              useWeb: Bool = true,
              executor: @escaping (String, [String: Any]) async -> String) async throws -> String {
        guard let key = Keychain.get("apiKey"), !key.isEmpty else { throw ClaudeError.noKey }

        var messages: [[String: Any]] = history.map { ["role": $0.role, "content": $0.text] }
        var toolsJSON: [[String: Any]] = []
        if useWeb { toolsJSON.append(["type": "web_search_20250305", "name": "web_search", "max_uses": 5]) }
        toolsJSON += tools.map { ["name": $0.name, "description": $0.description, "input_schema": $0.schema] }

        var collected: [String] = []
        for _ in 0..<8 {
            var body: [String: Any] = ["model": Self.model, "max_tokens": 1500, "system": system, "messages": messages]
            if !toolsJSON.isEmpty { body["tools"] = toolsJSON }

            var req = URLRequest(url: URL(string: "https://api.anthropic.com/v1/messages")!)
            req.httpMethod = "POST"
            req.timeoutInterval = 90
            req.setValue(key, forHTTPHeaderField: "x-api-key")
            req.setValue("2023-06-01", forHTTPHeaderField: "anthropic-version")
            req.setValue("application/json", forHTTPHeaderField: "content-type")
            req.httpBody = try JSONSerialization.data(withJSONObject: body)

            let (data, resp) = try await URLSession.shared.data(for: req)
            guard let http = resp as? HTTPURLResponse else { throw ClaudeError.badResponse }
            guard http.statusCode == 200 else { throw ClaudeError.http(http.statusCode) }
            guard let json = try JSONSerialization.jsonObject(with: data) as? [String: Any],
                  let content = json["content"] as? [[String: Any]] else { throw ClaudeError.badResponse }

            let text = content.filter { $0["type"] as? String == "text" }
                .compactMap { $0["text"] as? String }.joined()
            if !text.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty { collected.append(text) }

            let stop = json["stop_reason"] as? String
            messages.append(["role": "assistant", "content": content])

            if stop == "tool_use" {
                var results: [[String: Any]] = []
                for block in content where block["type"] as? String == "tool_use" {
                    let id = block["id"] as? String ?? ""
                    let name = block["name"] as? String ?? ""
                    let input = block["input"] as? [String: Any] ?? [:]
                    let out = await executor(name, input)
                    results.append(["type": "tool_result", "tool_use_id": id, "content": out])
                }
                messages.append(["role": "user", "content": results])
            } else if stop == "pause_turn" {
                continue
            } else {
                break
            }
        }
        return collected.joined(separator: " ").trimmingCharacters(in: .whitespacesAndNewlines)
    }

    /// Für Siri/Kurzbefehle: Frage mit Websuche, ohne Geräte-Werkzeuge.
    func quickAnswer(_ question: String) async throws -> String {
        let mems: [String] = await MainActor.run {
            ((try? Persistence.shared.mainContext.fetch(FetchDescriptor<Memory>())) ?? []).map(\.text)
        }
        return try await chat(history: [("user", question)],
                              system: Prompt.system(memories: mems),
                              tools: [],
                              executor: { _, _ in "Nicht verfügbar." })
    }
}
