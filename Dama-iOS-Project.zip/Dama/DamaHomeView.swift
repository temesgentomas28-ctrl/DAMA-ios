import SwiftUI

struct DamaBackground: View {
    var body: some View {
        LinearGradient(colors: [Color(red: 0.01, green: 0.02, blue: 0.05),
                                Color(red: 0.03, green: 0.07, blue: 0.14)],
                       startPoint: .top, endPoint: .bottom)
            .ignoresSafeArea()
    }
}

struct OrbView: View {
    let state: Assistant.State
    let level: CGFloat

    private var color: Color {
        switch state {
        case .idle: return .cyan
        case .listening: return Color(red: 0.3, green: 0.6, blue: 1)
        case .thinking: return .purple
        case .speaking: return Color(red: 0.2, green: 1, blue: 0.9)
        }
    }

    var body: some View {
        TimelineView(.animation) { tl in
            let t = tl.date.timeIntervalSinceReferenceDate
            let amp: Double = {
                switch state {
                case .idle: return 0.03
                case .listening: return 0.05 + Double(level) * 0.4
                case .thinking: return 0.04
                case .speaking: return 0.07 + 0.07 * abs(sin(t * 6))
                }
            }()
            let speed: Double = state == .thinking ? 3.5 : 1.4
            ZStack {
                ForEach(0..<3, id: \.self) { i in
                    Circle()
                        .fill(RadialGradient(colors: [color.opacity(0.55), color.opacity(0.05)],
                                             center: .center, startRadius: 5, endRadius: 130))
                        .scaleEffect(0.72 + 0.22 * Double(i) + amp * sin(t * speed + Double(i) * 2))
                        .blur(radius: CGFloat(4 + i * 5))
                }
                Circle()
                    .strokeBorder(AngularGradient(colors: [color, .white.opacity(0.1), color], center: .center), lineWidth: 2)
                    .scaleEffect(0.62 + amp * 0.6)
                    .rotationEffect(.degrees(t * (state == .thinking ? 240 : 30)))
                Circle().fill(color.opacity(0.85)).scaleEffect(0.16 + amp * 0.3).blur(radius: 3)
            }
            .shadow(color: color.opacity(0.5), radius: 30)
            .animation(.easeInOut(duration: 0.4), value: state)
        }
    }
}

struct DamaHomeView: View {
    @EnvironmentObject var a: Assistant
    @EnvironmentObject var speech: SpeechService
    @State private var showChat = false
    @State private var showSearch = false
    @State private var showSkills = false
    @State private var showTools = false

    var body: some View {
        ZStack {
            DamaBackground()
            VStack(spacing: 20) {
                HStack(spacing: 8) {
                    Text("DAMA").font(.system(.title3, design: .rounded).weight(.semibold)).tracking(8)
                        .foregroundStyle(.white.opacity(0.85))
                }
                .padding(.top, 8)

                if speech.isListening {
                    Label("Mikrofon aktiv", systemImage: "mic.fill")
                        .font(.caption.weight(.medium)).foregroundStyle(.red)
                        .padding(.horizontal, 10).padding(.vertical, 4)
                        .background(.red.opacity(0.15), in: Capsule())
                } else {
                    Color.clear.frame(height: 24)
                }

                Spacer()
                OrbView(state: a.state, level: speech.level)
                    .frame(width: 270, height: 270)
                    .contentShape(Circle())
                    .onTapGesture { a.toggleListening() }
                    .accessibilityLabel("Dama")
                    .accessibilityHint("Tippen zum Sprechen")

                Text(a.statusText).font(.callout).foregroundStyle(.secondary)

                ScrollView {
                    Text(a.state == .listening ? speech.transcript : a.lastReply)
                        .font(.body).foregroundStyle(.white.opacity(0.9))
                        .multilineTextAlignment(.center).padding(.horizontal, 24)
                }
                .frame(maxHeight: 140)
                Spacer()

                DamaQuickActionsView(actions: [
                    DamaQuickAction(title: "Chat", icon: "message"),
                    DamaQuickAction(title: "Datei", icon: "doc"),
                    DamaQuickAction(title: "Suche", icon: "magnifyingglass"),
                    DamaQuickAction(title: "Erinnerung", icon: "bell"),
                    DamaQuickAction(title: "Werkzeuge", icon: "square.grid.2x2")
                ]) { action in
                    if action.title == "Chat" { showChat = true }
                    else if action.title == "Erinnerung" { a.lastReply = "Sag mir, wann ich dich erinnern soll." }
                    else if action.title == "Suche" { showSearch = true }
                    else if action.title == "Datei" { a.lastReply = "Datei auswählen kannst du über den Chat." }
                    else if action.title == "Werkzeuge" { showTools = true }
                }
                .padding(.horizontal)

                HStack(spacing: 36) {
                    controlButton("text.bubble") { showChat = true }
                    Button { a.toggleListening() } label: {
                        Image(systemName: a.state == .listening ? "stop.fill" : "mic.fill")
                            .font(.title).foregroundStyle(.white)
                            .frame(width: 72, height: 72)
                            .background(a.state == .listening ? Color.red : Color.cyan.opacity(0.75), in: Circle())
                    }
                    controlButton("plus.bubble") { a.newConversation() }
                }
                .padding(.bottom, 16)
            }

            if let c = a.pending {
                Color.black.opacity(0.6).ignoresSafeArea()
                VStack(spacing: 16) {
                    Text("Bestätigung nötig").font(.headline)
                    Text(c.message).multilineTextAlignment(.center)
                    HStack(spacing: 12) {
                        Button("Abbrechen") { c.resolve(false) }.buttonStyle(.bordered).tint(.gray)
                        Button("Erlauben") { c.resolve(true) }.buttonStyle(.borderedProminent).tint(.cyan)
                    }
                }
                .padding(24)
                .background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: 20))
                .padding(32)
            }
        }
        .sheet(isPresented: $showSearch) {
            DamaSearchView()
        }
        .sheet(isPresented: $showTools) { NavigationStack { DamaRound3Hub() } }
        .sheet(isPresented: $showChat) {
            NavigationStack {
                ChatView(conversation: a.ensureConversation())
                    .toolbar { ToolbarItem(placement: .topBarTrailing) { Button("Fertig") { showChat = false } } }
            }
        }
    }

    private func controlButton(_ icon: String, action: @escaping () -> Void) -> some View {
        Button(action: action) {
            Image(systemName: icon).font(.title2).foregroundStyle(.white.opacity(0.85))
                .frame(width: 52, height: 52).background(.white.opacity(0.08), in: Circle())
        }
    }
}
