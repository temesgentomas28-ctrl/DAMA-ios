import Foundation
import SwiftData

@Model final class DamaProject {
    var id = UUID()
    var name: String
    var details: String
    var createdAt = Date()
    var updatedAt = Date()
    init(name: String, details: String = "") { self.name = name; self.details = details }
}

@Model final class DamaSavedItem {
    var id = UUID()
    var title: String
    var text: String
    var createdAt = Date()
    init(title: String, text: String) { self.title = title; self.text = text }
}

struct DamaSource: Identifiable, Codable {
    let id = UUID()
    let title: String
    let url: String
    let publisher: String?
}

struct DamaExport: Codable {
    let exportedAt: Date
    let conversations: [DamaExportConversation]
    let memories: [String]
    let projects: [DamaExportProject]
}
struct DamaExportConversation: Codable { let title: String; let messages: [DamaExportMessage] }
struct DamaExportMessage: Codable { let role: String; let text: String; let createdAt: Date }
struct DamaExportProject: Codable { let name: String; let details: String }

enum DamaDataManager {
    static func exportJSON(context: ModelContext) throws -> Data {
        let conversations = (try context.fetch(FetchDescriptor<Conversation>())).map { c in
            DamaExportConversation(title: c.title, messages: c.messages.sorted { $0.createdAt < $1.createdAt }.map { DamaExportMessage(role: $0.role, text: $0.text, createdAt: $0.createdAt) })
        }
        let memories = (try context.fetch(FetchDescriptor<Memory>())).map(\.text)
        let projects = (try context.fetch(FetchDescriptor<DamaProject>())).map { DamaExportProject(name: $0.name, details: $0.details) }
        return try JSONEncoder().encode(DamaExport(exportedAt: Date(), conversations: conversations, memories: memories, projects: projects))
    }
}
