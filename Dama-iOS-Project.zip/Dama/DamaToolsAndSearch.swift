import Foundation

// MARK: - Tool/Skill metadata used by Round 2 orchestration

struct DamaSourceRecord: Identifiable, Codable, Hashable {
    var id = UUID()
    var title: String
    var url: String?
    var publisher: String?
    var retrievedAt: Date = .now
    var confidence: Double
}

enum DamaConfidenceLabel: String {
    case high = "hoch"
    case medium = "mittel"
    case low = "niedrig"
}

struct DamaAnswerMetadata: Codable, Hashable {
    var sources: [DamaSourceRecord] = []
    var confidence: Double = 1
    var isCurrentInformation: Bool = false
    var generatedAt: Date = .now

    var label: DamaConfidenceLabel {
        if confidence >= 0.8 { return .high }
        if confidence >= 0.5 { return .medium }
        return .low
    }
}

struct DamaSkillRequest: Codable, Hashable {
    var skillID: String
    var input: String
    var requestedAt: Date = .now
}

struct DamaSkillResult: Codable, Hashable {
    var skillID: String
    var text: String
    var metadata: DamaAnswerMetadata
}

protocol DamaSkillExecutor {
    func execute(_ request: DamaSkillRequest) async throws -> DamaSkillResult
}

struct DamaKnowledgeSkill: DamaSkillExecutor {
    func execute(_ request: DamaSkillRequest) async throws -> DamaSkillResult {
        DamaSkillResult(skillID: request.skillID, text: request.input, metadata: DamaAnswerMetadata(confidence: 0.6))
    }
}

struct DamaSkillRouter {
    static func route(_ text: String) -> DamaSkillCategory? {
        let lower = text.lowercased()
        if lower.contains("suche") || lower.contains("aktuell") || lower.contains("heute") || lower.contains("quelle") { return .search }
        if lower.contains("rechne") || lower.contains("gleichung") || lower.contains("mathe") { return .math }
        if lower.contains("übersetze") || lower.contains("translate") { return .translation }
        if lower.contains("code") || lower.contains("swift") || lower.contains("python") { return .coding }
        if lower.contains("lern") || lower.contains("schule") || lower.contains("erkläre") { return .learning }
        if lower.contains("schreib") || lower.contains("nachricht") || lower.contains("brief") { return .writing }
        return .knowledge
    }
}
