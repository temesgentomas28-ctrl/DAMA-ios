import EventKit
import Contacts
import UIKit

/// Geräte-Aktionen. Jede Funktion verwendet nur die jeweils erteilte Berechtigung.
@MainActor
final class DeviceActions {
    private let store = EKEventStore()

    static func parseDate(_ s: String) -> Date? {
        let f = ISO8601DateFormatter()
        if let d = f.date(from: s) { return d }
        f.formatOptions = [.withInternetDateTime, .withFractionalSeconds]
        if let d = f.date(from: s) { return d }
        let l = DateFormatter()
        l.locale = Locale(identifier: "en_US_POSIX")
        l.timeZone = .current
        for fmt in ["yyyy-MM-dd'T'HH:mm:ss", "yyyy-MM-dd'T'HH:mm", "yyyy-MM-dd HH:mm", "yyyy-MM-dd"] {
            l.dateFormat = fmt
            if let d = l.date(from: s) { return d }
        }
        return nil
    }

    func createReminder(title: String, due: Date?) async -> String {
        do {
            guard try await store.requestFullAccessToReminders() else {
                return "Kein Zugriff auf Erinnerungen. Der Nutzer muss das in den iOS-Einstellungen erlauben."
            }
            let r = EKReminder(eventStore: store)
            r.title = title
            r.calendar = store.defaultCalendarForNewReminders()
            if let due {
                r.dueDateComponents = Calendar.current.dateComponents([.year, .month, .day, .hour, .minute], from: due)
                r.addAlarm(EKAlarm(absoluteDate: due))
            }
            try store.save(r, commit: true)
            return "Erinnerung erstellt."
        } catch { return "Fehler: \(error.localizedDescription)" }
    }

    func createEvent(title: String, start: Date, end: Date?, location: String?) async -> String {
        do {
            guard try await store.requestFullAccessToEvents() else {
                return "Kein Zugriff auf den Kalender. Der Nutzer muss das in den iOS-Einstellungen erlauben."
            }
            let e = EKEvent(eventStore: store)
            e.title = title
            e.startDate = start
            e.endDate = end ?? start.addingTimeInterval(3600)
            e.location = location
            e.calendar = store.defaultCalendarForNewEvents
            try store.save(e, span: .thisEvent)
            return "Termin erstellt."
        } catch { return "Fehler: \(error.localizedDescription)" }
    }

    func listEvents(from: Date, to: Date) async -> String {
        do {
            guard try await store.requestFullAccessToEvents() else { return "Kein Zugriff auf den Kalender." }
            let pred = store.predicateForEvents(withStart: from, end: to, calendars: nil)
            let evs = store.events(matching: pred).sorted { $0.startDate < $1.startDate }.prefix(25)
            if evs.isEmpty { return "Keine Termine in diesem Zeitraum." }
            return evs.map { "\($0.startDate.formatted(date: .abbreviated, time: .shortened)): \($0.title ?? "")" }
                .joined(separator: "\n")
        } catch { return "Fehler: \(error.localizedDescription)" }
    }

    func findContact(_ name: String) async -> String {
        let cs = CNContactStore()
        do {
            guard try await cs.requestAccess(for: .contacts) else { return "Kein Zugriff auf Kontakte." }
            let keys = [CNContactGivenNameKey, CNContactFamilyNameKey, CNContactPhoneNumbersKey] as [CNKeyDescriptor]
            let res = try cs.unifiedContacts(matching: CNContact.predicateForContacts(matchingName: name), keyDescriptors: keys)
            if res.isEmpty { return "Kein Kontakt gefunden." }
            return res.prefix(5).map { c in
                "\(c.givenName) \(c.familyName): " + c.phoneNumbers.map { $0.value.stringValue }.joined(separator: ", ")
            }.joined(separator: "\n")
        } catch { return "Fehler: \(error.localizedDescription)" }
    }

    func open(_ urlString: String) async -> Bool {
        guard let u = URL(string: urlString) else { return false }
        return await UIApplication.shared.open(u)
    }
}
