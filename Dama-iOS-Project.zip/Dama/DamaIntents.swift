import AppIntents

/// „Hey Siri, öffne Dama“ – startet die App und hört sofort zu.
struct OpenDamaIntent: AppIntent {
    static var title: LocalizedStringResource = "Dama zuhören"
    static var description = IntentDescription("Öffnet Dama und startet das Zuhören.")
    static var openAppWhenRun = true

    func perform() async throws -> some IntentResult {
        UserDefaults.standard.set(true, forKey: "autoListenOnLaunch")
        return .result()
    }
}

/// Frage direkt über Siri oder einen Kurzbefehl stellen, ohne die App zu öffnen.
struct AskDamaIntent: AppIntent {
    static var title: LocalizedStringResource = "Dama fragen"
    static var description = IntentDescription("Stellt Dama eine Frage (mit Websuche) und liefert die Antwort.")

    @Parameter(title: "Frage", requestValueDialog: "Was möchtest du Dama fragen?")
    var question: String

    func perform() async throws -> some IntentResult & ReturnsValue<String> & ProvidesDialog {
        let answer = try await ClaudeService().quickAnswer(question)
        return .result(value: answer, dialog: IntentDialog(stringLiteral: answer))
    }
}

struct DamaShortcuts: AppShortcutsProvider {
    static var appShortcuts: [AppShortcut] {
        AppShortcut(intent: OpenDamaIntent(),
                    phrases: ["Öffne \(.applicationName)", "Starte \(.applicationName)",
                              "Hey \(.applicationName)", "Open \(.applicationName)"],
                    shortTitle: "Dama zuhören", systemImageName: "waveform")
        AppShortcut(intent: AskDamaIntent(),
                    phrases: ["Frag \(.applicationName)", "Ask \(.applicationName)"],
                    shortTitle: "Dama fragen", systemImageName: "questionmark.bubble")
    }
}
