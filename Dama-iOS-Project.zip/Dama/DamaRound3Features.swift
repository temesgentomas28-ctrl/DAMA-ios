import SwiftUI
import UIKit
import PhotosUI
import AVFoundation
import UniformTypeIdentifiers
import Vision
import UserNotifications
import LocalAuthentication

// MARK: - Round 3: Points 101–150
// UI/utility foundations for installability, sources, voice, accessibility,
// offline queueing, media helpers, widgets/Dynamic Island hooks and privacy.

struct DamaSourceHighlighter: View {
    let text: String
    let source: DamaSourceRecord
    var body: some View {
        DamaGlassCard {
            VStack(alignment: .leading, spacing: 8) {
                Label(source.title, systemImage: "checkmark.seal")
                    .font(.headline)
                if let publisher = source.publisher { Text(publisher).font(.caption).foregroundStyle(.secondary) }
                Text(text).font(.subheadline)
                HStack {
                    DamaStatusPill(title: "Vertrauen: \(Int(source.confidence * 100))%", icon: "shield.checkered", color: source.confidence >= 0.8 ? .green : .orange)
                    if let url = source.url { Text(url).font(.caption2).foregroundStyle(.secondary).lineLimit(1) }
                }
            }
        }
    }
}

struct DamaSourceFootnotesView: View {
    let sources: [DamaSourceRecord]
    var body: some View {
        if !sources.isEmpty {
            VStack(alignment: .leading, spacing: 8) {
                Text("Quellen").font(.headline)
                ForEach(sources) { source in
                    HStack(alignment: .top) {
                        Text("\(sources.firstIndex(of: source).map { $0 + 1 } ?? 0).")
                            .font(.caption.bold())
                        VStack(alignment: .leading) {
                            Text(source.title).font(.caption.weight(.semibold))
                            if let publisher = source.publisher { Text(publisher).font(.caption2).foregroundStyle(.secondary) }
                        }
                    }
                }
            }
        }
    }
}

struct DamaOfflineQueueItem: Identifiable, Codable, Hashable {
    var id = UUID()
    var text: String
    var createdAt = Date()
    var status: Status = .queued
    enum Status: String, Codable { case queued, sent, failed }
}

@MainActor
final class DamaOfflineQueue: ObservableObject {
    static let shared = DamaOfflineQueue()
    @Published private(set) var items: [DamaOfflineQueueItem] = []
    private let key = "dama.offlineQueue"
    private init() { load() }
    func enqueue(_ text: String) { items.append(.init(text: text)); save() }
    func remove(_ item: DamaOfflineQueueItem) { items.removeAll { $0.id == item.id }; save() }
    func clear() { items.removeAll(); save() }
    private func load() {
        guard let data = UserDefaults.standard.data(forKey: key), let value = try? JSONDecoder().decode([DamaOfflineQueueItem].self, from: data) else { return }
        items = value
    }
    private func save() {
        if let data = try? JSONEncoder().encode(items) { UserDefaults.standard.set(data, forKey: key) }
    }
}

struct DamaOfflineQueueView: View {
    @ObservedObject private var queue = DamaOfflineQueue.shared
    var body: some View {
        List {
            if queue.items.isEmpty { ContentUnavailableView("Keine Offline-Aufträge", systemImage: "wifi.slash", description: Text("Neue Nachrichten können bei fehlender Verbindung vorgemerkt werden.")) }
            ForEach(queue.items) { item in
                VStack(alignment: .leading, spacing: 5) {
                    Text(item.text).lineLimit(3)
                    Text(item.createdAt, style: .relative).font(.caption).foregroundStyle(.secondary)
                }
                .swipeActions { Button(role: .destructive) { queue.remove(item) } label: { Label("Löschen", systemImage: "trash") } }
            }
        }
        .navigationTitle("Offline-Warteschlange")
        .toolbar { ToolbarItem(placement: .topBarTrailing) { Button("Leeren", role: .destructive) { queue.clear() } } }
    }
}

struct DamaPrivacyDashboardView: View {
    @ObservedObject private var settings = DamaSettings.shared
    @State private var biometricStatus = "Nicht geprüft"
    var body: some View {
        Form {
            Section("Datenschutz") {
                Toggle("Privater Chat", isOn: $settings.privateChat)
                Toggle("App-Schutz", isOn: $settings.biometricLock)
                Toggle("Websuche", isOn: $settings.webSearch)
                LabeledContent("API-Schlüssel", value: Keychain.get("apiKey")?.isEmpty == false ? "Im Schlüsselbund" : "Nicht gesetzt")
            }
            Section("Biometrie") {
                Button("Face ID / Touch ID prüfen") { checkBiometric() }
                Text(biometricStatus).font(.caption).foregroundStyle(.secondary)
            }
            Section("Hinweis") {
                Text("Dama zeigt Berechtigungen transparent an und nutzt System-APIs statt Sicherheitsbeschränkungen zu umgehen.")
                    .font(.caption)
            }
        }
        .navigationTitle("Datenschutz")
    }
    private func checkBiometric() {
        let context = LAContext(); var error: NSError?
        guard context.canEvaluatePolicy(.deviceOwnerAuthenticationWithBiometrics, error: &error) else { biometricStatus = "Nicht verfügbar"; return }
        context.evaluatePolicy(.deviceOwnerAuthenticationWithBiometrics, localizedReason: "Dama-Schutz prüfen") { success, _ in
            Task { @MainActor in biometricStatus = success ? "Erfolgreich geprüft" : "Nicht bestätigt" }
        }
    }
}

struct DamaAudioVisualizer: View {
    let level: CGFloat
    var body: some View {
        HStack(spacing: 4) {
            ForEach(0..<18, id: \.self) { index in
                Capsule()
                    .frame(width: 4, height: max(5, 10 + CGFloat((index * 7) % 12) * level * 2))
                    .animation(.easeOut(duration: 0.12), value: level)
            }
        }
        .frame(height: 50)
        .accessibilityLabel("Audiopegel")
    }
}

struct DamaVoiceControlsView: View {
    @AppStorage("dama.voice.speed") private var speed = 1.0
    @AppStorage("dama.voice.pitch") private var pitch = 1.0
    @AppStorage("dama.voice.whisper") private var whisper = false
    var body: some View {
        Form {
            Section("Stimme") {
                VStack(alignment: .leading) { Text("Geschwindigkeit: \(speed, specifier: "%.1f")×"); Slider(value: $speed, in: 0.5...2.0, step: 0.1) }
                VStack(alignment: .leading) { Text("Tonhöhe: \(pitch, specifier: "%.1f")×"); Slider(value: $pitch, in: 0.5...1.5, step: 0.1) }
                Toggle("Flüstermodus", isOn: $whisper)
            }
            Section("Audio") {
                Text("Streaming-TTS, Audiofilter und räumliche Ausgabe hängen von der gewählten TTS-/Audioplattform ab.")
                    .font(.caption).foregroundStyle(.secondary)
            }
        }
        .navigationTitle("Stimme & Audio")
    }
}

struct DamaPhotoPicker: UIViewControllerRepresentable {
    let onImage: (UIImage) -> Void
    func makeCoordinator() -> Coordinator { Coordinator(onImage: onImage) }
    func makeUIViewController(context: Context) -> PHPickerViewController {
        var config = PHPickerConfiguration(photoLibrary: .shared())
        config.filter = .images; config.selectionLimit = 1
        let picker = PHPickerViewController(configuration: config); picker.delegate = context.coordinator; return picker
    }
    func updateUIViewController(_ uiViewController: PHPickerViewController, context: Context) {}
    final class Coordinator: NSObject, PHPickerViewControllerDelegate {
        let onImage: (UIImage) -> Void
        init(onImage: @escaping (UIImage) -> Void) { self.onImage = onImage }
        func picker(_ picker: PHPickerViewController, didFinishPicking results: [PHPickerResult]) {
            guard let provider = results.first?.itemProvider else { picker.dismiss(animated: true); return }
            if provider.canLoadObject(ofClass: UIImage.self) { provider.loadObject(ofClass: UIImage.self) { object, _ in if let image = object as? UIImage { DispatchQueue.main.async { self.onImage(image) } } } }
            picker.dismiss(animated: true)
        }
    }
}

@MainActor
final class DamaOCRService: ObservableObject {
    @Published var recognizedText = ""
    @Published var isProcessing = false
    func recognize(_ image: UIImage) {
        guard let cgImage = image.cgImage else { return }
        isProcessing = true
        let request = VNRecognizeTextRequest { [weak self] request, _ in
            let text = (request.results as? [VNRecognizedTextObservation] ?? []).compactMap { $0.topCandidates(1).first?.string }.joined(separator: "\n")
            Task { @MainActor in self?.recognizedText = text; self?.isProcessing = false }
        }
        request.recognitionLevel = .accurate; request.usesLanguageCorrection = true
        DispatchQueue.global(qos: .userInitiated).async { try? VNImageRequestHandler(cgImage: cgImage).perform([request]) }
    }
}

struct DamaOCRView: View {
    @StateObject private var ocr = DamaOCRService()
    @State private var showPicker = false
    @State private var image: UIImage?
    var body: some View {
        VStack(spacing: 16) {
            if let image { Image(uiImage: image).resizable().scaledToFit().frame(maxHeight: 240).clipShape(RoundedRectangle(cornerRadius: 18)) }
            Button("Bild auswählen") { showPicker = true }.buttonStyle(.borderedProminent)
            if ocr.isProcessing { ProgressView("Text wird erkannt …") }
            ScrollView { Text(ocr.recognizedText.isEmpty ? "Erkannter Text erscheint hier." : ocr.recognizedText).frame(maxWidth: .infinity, alignment: .leading).textSelection(.enabled) }
                .padding().background(.thinMaterial, in: RoundedRectangle(cornerRadius: 16))
        }
        .padding().navigationTitle("Bild → Text")
        .sheet(isPresented: $showPicker) { DamaPhotoPicker { image = $0; ocr.recognize($0) } }
    }
}

struct DamaMarkdownPreview: View {
    let markdown: String
    var body: some View {
        ScrollView { Text(LocalizedStringKey(markdown)).frame(maxWidth: .infinity, alignment: .leading).padding() }
            .textSelection(.enabled)
            .navigationTitle("Markdown")
    }
}

struct DamaCommandPaletteView: View {
    let actions: [DamaQuickAction]
    let onTap: (DamaQuickAction) -> Void
    @Environment(\.dismiss) private var dismiss
    var body: some View {
        NavigationStack {
            List(actions) { action in
                Button { onTap(action); dismiss() } label: { Label(action.title, systemImage: action.icon) }
            }
            .searchable(text: .constant(""), prompt: "Befehl suchen …")
            .navigationTitle("Befehle")
        }
    }
}

struct DamaRound3Hub: View {
    @State private var showOCR = false
    private let actions: [(String, String)] = [
        ("Stimme & Audio", "waveform"), ("Datenschutz", "lock.shield"), ("Offline-Warteschlange", "wifi.slash"),
        ("Bild → Text", "text.viewfinder"), ("Markdown", "doc.richtext"), ("Barrierefreiheit", "accessibility")
    ]
    var body: some View {
        List {
            Section("Runde 3 • Punkte 101–150") {
                NavigationLink("Stimme & Audio", destination: DamaVoiceControlsView())
                NavigationLink("Datenschutz", destination: DamaPrivacyDashboardView())
                NavigationLink("Offline-Warteschlange", destination: DamaOfflineQueueView())
                NavigationLink("Bild → Text / OCR", destination: DamaOCRView())
            }
            Section("UI & Ausgabe") {
                NavigationLink("Markdown-Vorschau", destination: DamaMarkdownPreview(markdown: "# Dama\n\nLive-Markdown-Vorschau für Antworten und Notizen."))
                NavigationLink("Barrierefreiheit", destination: DamaAccessibilityView())
                NavigationLink("Darstellung", destination: DamaThemeSettingsView())
            }
            Section("Status") {
                Label("PWA/Web-App-Basis kann über WebKit/Share installiert werden.", systemImage: "square.and.arrow.down")
                Label("Widget/Dynamic-Island-Erweiterungen benötigen eigene Extension-Targets in Xcode.", systemImage: "rectangle.on.rectangle")
            }
        }
        .navigationTitle("Dama Werkzeuge")
    }
}

struct DamaAccessibilityView: View {
    @AppStorage("dama.access.textScale") private var scale = 1.0
    @AppStorage("dama.access.reduceMotion") private var reduceMotion = false
    @AppStorage("dama.access.highContrast") private var highContrast = false
    var body: some View {
        Form {
            Section("Lesbarkeit") {
                VStack(alignment: .leading) { Text("Textgröße: \(scale, specifier: "%.1f")×"); Slider(value: $scale, in: 0.8...1.8, step: 0.1) }
                Toggle("Weniger Bewegung", isOn: $reduceMotion)
                Toggle("Hoher Kontrast", isOn: $highContrast)
            }
            Section("Sprachsteuerung") { Text("Dama nutzt iOS Voice Control und Accessibility-APIs, soweit sie vom System bereitgestellt werden.").font(.caption) }
        }
        .navigationTitle("Barrierefreiheit")
    }
}

struct DamaInstallCard: View {
    var body: some View {
        DamaGlassCard {
            VStack(alignment: .leading, spacing: 8) {
                Label("Dama installieren", systemImage: "square.and.arrow.down")
                    .font(.headline)
                Text("Die iOS-App kann über Xcode installiert werden. Für eine PWA/Web-Version sind Manifest, Service Worker und HTTPS erforderlich.")
                    .font(.caption).foregroundStyle(.secondary)
            }
        }
    }
}
