import AVFoundation
import Speech
import NaturalLanguage
import SwiftUI

@MainActor
final class SpeechService: NSObject, ObservableObject, AVSpeechSynthesizerDelegate {
    @Published var isListening = false
    @Published var isSpeaking = false
    @Published var transcript = ""
    @Published var level: CGFloat = 0

    private let engine = AVAudioEngine()
    private var request: SFSpeechAudioBufferRecognitionRequest?
    private var task: SFSpeechRecognitionTask?
    private var silenceTimer: Timer?
    private let synth = AVSpeechSynthesizer()
    private var onSpeakEnd: (() -> Void)?

    override init() {
        super.init()
        synth.delegate = self
    }

    // MARK: Berechtigungen

    static func requestPermissions() async -> Bool {
        let speech = await withCheckedContinuation { (c: CheckedContinuation<Bool, Never>) in
            SFSpeechRecognizer.requestAuthorization { c.resume(returning: $0 == .authorized) }
        }
        let mic = await AVAudioApplication.requestRecordPermission()
        return speech && mic
    }

    private func configureSession() {
        let s = AVAudioSession.sharedInstance()
        try? s.setCategory(.playAndRecord, mode: .default, options: [.defaultToSpeaker, .allowBluetooth])
        try? s.setActive(true)
    }

    // MARK: Zuhören

    func startListening(locale: String, silence: TimeInterval = 1.6,
                        onFinal: @escaping (String) -> Void) {
        stopListening()
        stopSpeaking()
        guard let recognizer = SFSpeechRecognizer(locale: Locale(identifier: locale)),
              recognizer.isAvailable else { onFinal(""); return }
        configureSession()

        let req = SFSpeechAudioBufferRecognitionRequest()
        req.shouldReportPartialResults = true
        request = req

        let input = engine.inputNode
        let format = input.outputFormat(forBus: 0)
        input.removeTap(onBus: 0)
        input.installTap(onBus: 0, bufferSize: 1024, format: format) { [weak self] buffer, _ in
            req.append(buffer)
            let l = SpeechService.rms(buffer)
            Task { @MainActor in self?.level = l }
        }
        engine.prepare()
        do { try engine.start() } catch { onFinal(""); return }

        transcript = ""
        isListening = true
        task = recognizer.recognitionTask(with: req) { [weak self] result, error in
            Task { @MainActor in
                guard let self, self.isListening else { return }
                if let r = result {
                    self.transcript = r.bestTranscription.formattedString
                    self.silenceTimer?.invalidate()
                    if !self.transcript.isEmpty {
                        self.silenceTimer = Timer.scheduledTimer(withTimeInterval: silence, repeats: false) { _ in
                            Task { @MainActor in self.finish(onFinal) }
                        }
                    }
                    if r.isFinal { self.finish(onFinal) }
                }
                if error != nil { self.finish(onFinal) }
            }
        }
    }

    private func finish(_ cb: (String) -> Void) {
        guard isListening else { return }
        let t = transcript
        stopListening()
        cb(t)
    }

    func stopListening() {
        silenceTimer?.invalidate()
        if engine.isRunning { engine.stop() }
        engine.inputNode.removeTap(onBus: 0)
        request?.endAudio()
        task?.cancel()
        request = nil; task = nil
        isListening = false
        level = 0
    }

    nonisolated static func rms(_ buffer: AVAudioPCMBuffer) -> CGFloat {
        guard let ch = buffer.floatChannelData?[0] else { return 0 }
        let n = Int(buffer.frameLength)
        guard n > 0 else { return 0 }
        var sum: Float = 0
        for i in 0..<n { sum += ch[i] * ch[i] }
        return CGFloat(min(1, sqrt(sum / Float(n)) * 8))
    }

    // MARK: Sprechen

    func speak(_ text: String, rate: Float, completion: (() -> Void)?) {
        stopListening()
        configureSession()
        let lang = Self.detectLanguage(text)
        let u = AVSpeechUtterance(string: text)
        u.voice = Self.bestMaleVoice(lang)
        u.rate = min(max(rate, 0.3), 0.6)
        u.pitchMultiplier = 0.92
        onSpeakEnd = completion
        isSpeaking = true
        synth.speak(u)
    }

    func stopSpeaking() {
        onSpeakEnd = nil
        if synth.isSpeaking { synth.stopSpeaking(at: .immediate) }
        isSpeaking = false
    }

    nonisolated func speechSynthesizer(_ s: AVSpeechSynthesizer, didFinish u: AVSpeechUtterance) {
        Task { @MainActor in
            self.isSpeaking = false
            let c = self.onSpeakEnd; self.onSpeakEnd = nil
            c?()
        }
    }
    nonisolated func speechSynthesizer(_ s: AVSpeechSynthesizer, didCancel u: AVSpeechUtterance) {
        Task { @MainActor in self.isSpeaking = false }
    }

    static func detectLanguage(_ text: String) -> String {
        let r = NLLanguageRecognizer()
        r.processString(text)
        return r.dominantLanguage == .english ? "en-US" : "de-DE"
    }

    /// Sanfte männliche Stimme: bevorzugt hochwertige (Enhanced/Premium) Stimmen bekannter männlicher Namen.
    static func bestMaleVoice(_ lang: String) -> AVSpeechSynthesisVoice? {
        let prefix = String(lang.prefix(2))
        let names = ["Markus", "Martin", "Daniel", "Aaron", "Evan", "Tom", "Arthur", "Gordon", "Reed", "Alex"]
        let voices = AVSpeechSynthesisVoice.speechVoices()
            .filter { $0.language.hasPrefix(prefix) }
            .sorted { $0.quality.rawValue > $1.quality.rawValue }
        if let m = voices.first(where: { v in names.contains { v.name.contains($0) } }) { return m }
        return voices.first ?? AVSpeechSynthesisVoice(language: lang)
    }
}
