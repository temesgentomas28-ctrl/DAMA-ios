import SwiftUI
import SwiftData
import UIKit

@MainActor
final class Assistant: ObservableObject {
    enum State { case idle, listening, thinking, speaking }
    struct Confirmation: Identifiable {
        let id = UUID()
        let message: String
        let resolve: (Bool) -> Void
    }

    @Published var state: State = .idle
    @Published var lastReply = ""
    @Published var pending: Confirmation?
    @Published var current: Conversation?

    let speech: SpeechService
    private let claude = ClaudeService()
    private let device = DeviceActions()
    private var context: ModelContext { Persistence.shared.mainContext }
    private var wakeActive = false

    init(speech: SpeechService) { self.speech = speech }

    // MARK: Einstellungen

    private var defaults: UserDefaults { .standard }
    private func flag(_ k: String, _ def: Bool) -> Bool { defaults.object(forKey: k) as? Bool ?? def }
    private var speakReplies: Bool { flag("speakReplies", true) }
    private var conversationMode: Bool { flag("conversationMode", false) }
    private var memoryEnabled: Bool { flag("memoryEnabled", true) }
    private var webSearch: Bool { flag("webSearch", true) }
    private var rate: Float { Float(defaults.object(forKey: "rate") as? Double ?? 0.5) }

    var listenLocale: String {
        switch defaults.string(forKey: "language") ?? "auto" {
        case "de": return "de-DE"
        case "en": return "en-US"
        default: return (Locale.preferredLanguages.first ?? "de").hasPrefix("en") ? "en-US" : "de-DE"
        }
    }

    var statusText: String {
        switch state {
        case .listening: return "Ich höre zu …"
        case .thinking: return "Ich denke nach …"
        case .speaking: return "Dama spricht"
        case .idle: return speech.isListening ? "Warte auf „Hey Dama“" : "Tippe auf die Kugel"
        }
    }

    // MARK: Gespräche

    func ensureConversation() -> Conversation {
        if let c = current { return c }
        let c = Conversation()
        context.insert(c)
        current = c
        return c
    }
    func newConversation() {
        speech.stopListening(); speech.stopSpeaking()
        current = nil; state = .idle; lastReply = ""
        resumeWake()
    }
    func open(_ c: Conversation) { current = c }

    // MARK: App-Lebenszyklus

    func appBecameActive(wake: Bool) {
        if defaults.bool(forKey: "autoListenOnLaunch") {
            defaults.set(false, forKey: "autoListenOnLaunch")
            startListening()
        } else {
            setWake(wake)
        }
    }
    func appWentBackground() {
        // iOS erlaubt im Hintergrund keinen Mikrofon-Dauerbetrieb für Apps.
        if state == .idle || state == .listening { speech.stopListening(); state = .idle }
    }

    // MARK: Zuhören

    func toggleListening() {
        switch state {
        case .listening: speech.stopListening(); state = .idle; resumeWake()
        case .speaking: speech.stopSpeaking(); state = .idle; resumeWake()
        case .thinking: break
        case .idle: startListening()
        }
    }

    func startListening() {
        Task {
            guard await SpeechService.requestPermissions() else {
                lastReply = "Bitte erlaube Mikrofon und Spracherkennung in den iOS-Einstellungen."
                return
            }
            UIImpactFeedbackGenerator(style: .light).impactOccurred()
            state = .listening
            speech.startListening(locale: listenLocale) { [weak self] text in
                guard let self else { return }
                let t = text.trimmingCharacters(in: .whitespacesAndNewlines)
                if t.isEmpty { self.state = .idle; self.resumeWake(); return }
                Task { await self.send(t) }
            }
        }
    }

    // MARK: Aktivierungswort (nur solange die App im Vordergrund ist)

    func setWake(_ on: Bool) {
        wakeActive = on
        if on { listenForWake() } else if state == .idle { speech.stopListening() }
    }
    private func resumeWake() { if wakeActive { listenForWake() } }

    private func listenForWake() {
        guard wakeActive, state == .idle, !speech.isListening else { return }
        Task {
            guard await SpeechService.requestPermissions() else { return }
            speech.startListening(locale: listenLocale, silence: 1.4) { [weak self] text in
                guard let self else { return }
                if let cmd = Self.command(afterWakeWordIn: text) {
                    UIImpactFeedbackGenerator(style: .medium).impactOccurred()
                    if cmd.isEmpty { self.startListening() } else { Task { await self.send(cmd) } }
                } else {
                    DispatchQueue.main.asyncAfter(deadline: .now() + 0.6) { self.listenForWake() }
                }
            }
        }
    }

    static func command(afterWakeWordIn text: String) -> String? {
        for p in ["hey dama", "hallo dama", "hi dama", "okay dama", "ok dama"] {
            if let r = text.range(of: p, options: .caseInsensitive) {
                return String(text[r.upperBound...]).trimmingCharacters(in: CharacterSet(charactersIn: " ,.!?"))
            }
        }
        return nil
    }

    // MARK: Anfrage senden

    func send(_ text: String) async {
        let trimmed = text.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !trimmed.isEmpty else { return }
        let convo = ensureConversation()
        let um = ChatMessage(role: "user", text: trimmed)
        context.insert(um)
        convo.messages.append(um)
        if convo.title == "Neues Gespräch" { convo.title = String(trimmed.prefix(40)) }
        state = .thinking

        var history = convo.messages.sorted { $0.createdAt < $1.createdAt }
            .suffix(30).map { (role: $0.role, text: $0.text) }
        while history.first?.role == "assistant" { history.removeFirst() }

        let mems: [String] = memoryEnabled
            ? ((try? context.fetch(FetchDescriptor<Memory>())) ?? []).map(\.text) : []

        var reply: String
        do {
            reply = try await claude.chat(
                history: history, system: Prompt.system(memories: mems),
                tools: toolDefs(), useWeb: webSearch,
                executor: { [weak self] n, i in await self?.execute(n, i) ?? "Fehler." })
        } catch {
            reply = error.localizedDescription
        }
        if reply.isEmpty { reply = "Erledigt." }

        let am = ChatMessage(role: "assistant", text: reply)
        context.insert(am)
        convo.messages.append(am)
        try? context.save()
        lastReply = reply

        if speakReplies {
            state = .speaking
            speech.speak(reply, rate: rate) { [weak self] in self?.finishedSpeaking() }
        } else {
            state = .idle
            resumeWake()
        }
    }

    private func finishedSpeaking() {
        state = .idle
        if conversationMode { startListening() } else { resumeWake() }
    }

    // MARK: Bestätigungen

    func confirm(_ message: String) async -> Bool {
        await withCheckedContinuation { c in
            pending = Confirmation(message: message) { [weak self] ok in
                self?.pending = nil
                c.resume(returning: ok)
            }
        }
    }

    // MARK: Werkzeuge

    private func obj(_ props: [String: String], required: [String]) -> [String: Any] {
        ["type": "object",
         "properties": props.mapValues { ["type": "string", "description": $0] },
         "required": required]
    }

    private func toolDefs() -> [ToolDef] {
        [
            ToolDef(name: "save_memory", description: "Speichert eine dauerhafte Information über den Nutzer.",
                    schema: obj(["text": "Die Information, kurz und eigenständig formuliert"], required: ["text"])),
            ToolDef(name: "forget_memory", description: "Löscht gespeicherte Erinnerungen, die den Suchbegriff enthalten.",
                    schema: obj(["query": "Suchbegriff"], required: ["query"])),
            ToolDef(name: "create_reminder", description: "Erstellt eine Erinnerung in der iOS-Erinnerungen-App.",
                    schema: obj(["title": "Titel", "due": "Fälligkeit, ISO-8601 (optional)"], required: ["title"])),
            ToolDef(name: "create_event", description: "Erstellt einen Kalendertermin.",
                    schema: obj(["title": "Titel", "start": "Beginn, ISO-8601", "end": "Ende, ISO-8601 (optional)", "location": "Ort (optional)"],
                                required: ["title", "start"])),
            ToolDef(name: "list_events", description: "Listet Kalendertermine in einem Zeitraum auf.",
                    schema: obj(["from": "Beginn, ISO-8601", "to": "Ende, ISO-8601"], required: ["from", "to"])),
            ToolDef(name: "find_contact", description: "Sucht einen Kontakt nach Namen und liefert Telefonnummern.",
                    schema: obj(["name": "Name"], required: ["name"])),
            ToolDef(name: "compose_message", description: "Öffnet die Nachrichten-App mit vorbereitetem Text. Der Nutzer tippt selbst auf Senden.",
                    schema: obj(["recipient": "Telefonnummer (nutze find_contact bei Namen)", "body": "Nachrichtentext"], required: ["recipient", "body"])),
            ToolDef(name: "start_navigation", description: "Startet die Navigation in Apple Karten.",
                    schema: obj(["destination": "Zieladresse oder Ortsname"], required: ["destination"])),
            ToolDef(name: "open_url", description: "Öffnet eine URL oder ein App-URL-Schema (https, tel, facetime, music, shortcuts, App-Schemas …).",
                    schema: obj(["url": "Die URL"], required: ["url"])),
            ToolDef(name: "search_web", description: "Öffnet eine Websuche für aktuelle Informationen. Dama zeigt die Suche transparent im Web an.",
                    schema: obj(["query": "Suchbegriff"], required: ["query"])),
            ToolDef(name: "run_shortcut", description: "Führt einen iOS-Kurzbefehl des Nutzers anhand seines Namens aus (z. B. für Automationen wie „Abend“).",
                    schema: obj(["name": "Name des Kurzbefehls", "input": "Optionaler Text-Input"], required: ["name"])),
        ]
    }

    private func execute(_ name: String, _ input: [String: Any]) async -> String {
        func s(_ k: String) -> String? { (input[k] as? String).flatMap { $0.isEmpty ? nil : $0 } }
        switch name {
        case "save_memory":
            guard memoryEnabled else { return "Das Gedächtnis ist in den Einstellungen deaktiviert." }
            guard let t = s("text") else { return "Kein Text." }
            let all = (try? context.fetch(FetchDescriptor<Memory>())) ?? []
            if all.contains(where: { $0.text.lowercased() == t.lowercased() }) { return "Schon gespeichert." }
            context.insert(Memory(text: t)); try? context.save()
            return "Gespeichert."
        case "forget_memory":
            guard let q = s("query")?.lowercased() else { return "Kein Suchbegriff." }
            let hits = ((try? context.fetch(FetchDescriptor<Memory>())) ?? []).filter { $0.text.lowercased().contains(q) }
            if hits.isEmpty { return "Nichts gefunden." }
            guard await confirm("\(hits.count) Erinnerung(en) löschen?") else { return "Vom Nutzer abgelehnt." }
            hits.forEach { context.delete($0) }; try? context.save()
            return "\(hits.count) gelöscht."
        case "create_reminder":
            guard let t = s("title") else { return "Kein Titel." }
            return await device.createReminder(title: t, due: s("due").flatMap(DeviceActions.parseDate))
        case "create_event":
            guard let t = s("title"), let st = s("start").flatMap(DeviceActions.parseDate) else { return "Titel oder Startzeit ungültig." }
            return await device.createEvent(title: t, start: st, end: s("end").flatMap(DeviceActions.parseDate), location: s("location"))
        case "list_events":
            guard let f = s("from").flatMap(DeviceActions.parseDate), let t = s("to").flatMap(DeviceActions.parseDate) else { return "Zeitraum ungültig." }
            return await device.listEvents(from: f, to: t)
        case "find_contact":
            return await device.findContact(s("name") ?? "")
        case "compose_message":
            guard let r = s("recipient"), let b = s("body") else { return "Empfänger oder Text fehlt." }
            let enc = b.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed) ?? ""
            let ok = await device.open("sms:\(r)&body=\(enc)")
            return ok ? "Nachricht vorbereitet. Der Nutzer muss selbst auf Senden tippen." : "Nachrichten-App konnte nicht geöffnet werden."
        case "start_navigation":
            guard let d = s("destination")?.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed) else { return "Kein Ziel." }
            return await device.open("http://maps.apple.com/?daddr=\(d)&dirflg=d") ? "Navigation geöffnet." : "Karten konnte nicht geöffnet werden."
        case "search_web":
            guard let q = s("query"), let encoded = q.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed) else { return "Kein Suchbegriff." }
            let url = "https://www.google.com/search?q=\(encoded)"
            return await device.open(url) ? "Websuche geöffnet. Prüfe die Ergebnisse und Quellen." : "Websuche konnte nicht geöffnet werden."
        case "open_url":
            guard let u = s("url") else { return "Keine URL." }
            let l = u.lowercased()
            if !(l.hasPrefix("https://") || l.hasPrefix("http://")) {
                guard await confirm("Dama möchte öffnen:\n\(u)") else { return "Vom Nutzer abgelehnt." }
            }
            return await device.open(u) ? "Geöffnet." : "Konnte nicht geöffnet werden (App evtl. nicht installiert)."
        case "run_shortcut":
            guard let n = s("name") else { return "Kein Name." }
            guard await confirm("Kurzbefehl „\(n)“ ausführen?") else { return "Vom Nutzer abgelehnt." }
            var url = "shortcuts://run-shortcut?name=" + (n.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed) ?? n)
            if let i = s("input") { url += "&input=text&text=" + (i.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed) ?? i) }
            return await device.open(url) ? "Kurzbefehl gestartet." : "Kurzbefehl konnte nicht gestartet werden."
        default:
            return "Unbekanntes Werkzeug."
        }
    }
}
