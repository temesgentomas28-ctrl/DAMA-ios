import Foundation
import SwiftData
import Security

// MARK: - Datenmodelle

@Model final class Conversation {
    var id = UUID()
    var title: String
    var createdAt = Date()
    @Relationship(deleteRule: .cascade, inverse: \ChatMessage.conversation)
    var messages: [ChatMessage] = []
    init(title: String = "Neues Gespräch") { self.title = title }
}

@Model final class ChatMessage {
    var id = UUID()
    var role: String          // "user" | "assistant"
    var text: String
    var createdAt = Date()
    var conversation: Conversation?
    init(role: String, text: String) { self.role = role; self.text = text }
}

/// Dauerhafte Erinnerung. Der Nutzer sieht, ändert und löscht alles selbst.

@Model final class DamaFolder {
    var id = UUID()
    var name: String
    var createdAt = Date()
    init(name: String) { self.name = name }
}

@Model final class DamaNotification {
    var id = UUID()
    var title: String
    var body: String
    var createdAt = Date()
    var isRead = false
    init(title: String, body: String) { self.title = title; self.body = body }
}

@Model final class Memory {
    var id = UUID()
    var text: String
    var createdAt = Date()
    init(text: String) { self.text = text }
}

enum Persistence {
    static let shared: ModelContainer = {
        do { return try ModelContainer(for: Conversation.self, ChatMessage.self, Memory.self, DamaProject.self, DamaSavedItem.self, DamaFolder.self, DamaNotification.self) }
        catch { fatalError("SwiftData-Fehler: \(error)") }
    }()
}

// MARK: - Keychain (API-Schlüssel)

enum Keychain {
    private static func query(_ key: String) -> [String: Any] {
        [kSecClass as String: kSecClassGenericPassword,
         kSecAttrService as String: "dama",
         kSecAttrAccount as String: key]
    }
    static func set(_ key: String, _ value: String) {
        SecItemDelete(query(key) as CFDictionary)
        guard !value.isEmpty else { return }
        var q = query(key)
        q[kSecValueData as String] = Data(value.utf8)
        q[kSecAttrAccessible as String] = kSecAttrAccessibleAfterFirstUnlock
        SecItemAdd(q as CFDictionary, nil)
    }
    static func get(_ key: String) -> String? {
        var q = query(key)
        q[kSecReturnData as String] = true
        q[kSecMatchLimit as String] = kSecMatchLimitOne
        var out: AnyObject?
        guard SecItemCopyMatching(q as CFDictionary, &out) == errSecSuccess,
              let d = out as? Data else { return nil }
        return String(data: d, encoding: .utf8)
    }
}
