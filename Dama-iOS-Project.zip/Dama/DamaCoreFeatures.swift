import SwiftUI
import UIKit
import PhotosUI
import UniformTypeIdentifiers

// MARK: - Round 1: Features 1–50 foundation

enum DamaModelMode: String, CaseIterable, Identifiable {
    case fast = "FAST"
    case standard = "STANDARD"
    case strong = "STRONG"
    var id: String { rawValue }
    var subtitle: String {
        switch self { case .fast: return "Schnelle Antworten"; case .standard: return "Code, Dateien & Bilder"; case .strong: return "Komplexe Analyse & Recherche" }
    }
}

enum DamaTheme: String, CaseIterable, Identifiable {
    case classic = "Classic", dark = "Dark", minimal = "Minimal", neon = "Neon", glass = "Glass", elegant = "Elegant"
    var id: String { rawValue }
}

enum DamaAccent: String, CaseIterable, Identifiable {
    case cyan, blue, purple, green, orange, pink
    var id: String { rawValue }
    var color: Color {
        switch self { case .cyan: return .cyan; case .blue: return .blue; case .purple: return .purple; case .green: return .green; case .orange: return .orange; case .pink: return .pink }
    }
}

@MainActor
final class DamaSettings: ObservableObject {
    static let shared = DamaSettings()
    @Published var modelMode: DamaModelMode { didSet { UserDefaults.standard.set(modelMode.rawValue, forKey: "dama.modelMode") } }
    @Published var theme: DamaTheme { didSet { UserDefaults.standard.set(theme.rawValue, forKey: "dama.theme") } }
    @Published var accent: DamaAccent { didSet { UserDefaults.standard.set(accent.rawValue, forKey: "dama.accent") } }
    @Published var language: String { didSet { UserDefaults.standard.set(language, forKey: "language") } }
    @Published var animations: Bool { didSet { UserDefaults.standard.set(animations, forKey: "dama.animations") } }
    @Published var privateChat: Bool { didSet { UserDefaults.standard.set(privateChat, forKey: "dama.privateChat") } }
    @Published var biometricLock: Bool { didSet { UserDefaults.standard.set(biometricLock, forKey: "dama.biometricLock") } }
    @Published var webSearch: Bool { didSet { UserDefaults.standard.set(webSearch, forKey: "webSearch") } }

    private init() {
        let d = UserDefaults.standard
        modelMode = DamaModelMode(rawValue: d.string(forKey: "dama.modelMode") ?? "STANDARD") ?? .standard
        theme = DamaTheme(rawValue: d.string(forKey: "dama.theme") ?? "Dark") ?? .dark
        accent = DamaAccent(rawValue: d.string(forKey: "dama.accent") ?? "cyan") ?? .cyan
        language = d.string(forKey: "language") ?? "de"
        animations = d.object(forKey: "dama.animations") as? Bool ?? true
        privateChat = d.object(forKey: "dama.privateChat") as? Bool ?? false
        biometricLock = d.object(forKey: "dama.biometricLock") as? Bool ?? false
        webSearch = d.object(forKey: "webSearch") as? Bool ?? true
    }
}

struct DamaActionPreview: Identifiable {
    let id = UUID()
    let title: String
    let detail: String
    let action: () -> Void
}

struct DamaQuickAction: Identifiable {
    let id = UUID()
    let title: String
    let icon: String
}

struct DamaAttachment: Identifiable {
    let id = UUID()
    let name: String
    let type: String
    let data: Data?
}

struct DamaStatusPill: View {
    let title: String
    let icon: String
    let color: Color
    var body: some View {
        Label(title, systemImage: icon)
            .font(.caption.weight(.semibold))
            .foregroundStyle(color)
            .padding(.horizontal, 10).padding(.vertical, 6)
            .background(color.opacity(0.12), in: Capsule())
    }
}

struct DamaGlassCard<Content: View>: View {
    @ViewBuilder var content: () -> Content
    var body: some View {
        content().padding(14)
            .background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: 20, style: .continuous))
            .overlay(RoundedRectangle(cornerRadius: 20).stroke(.white.opacity(0.08)))
    }
}

struct DamaQuickActionsView: View {
    let actions: [DamaQuickAction]
    let onTap: (DamaQuickAction) -> Void
    var body: some View {
        ScrollView(.horizontal, showsIndicators: false) {
            HStack(spacing: 10) {
                ForEach(actions) { action in
                    Button { onTap(action) } label: {
                        Label(action.title, systemImage: action.icon)
                            .font(.caption.weight(.medium))
                            .padding(.horizontal, 12).padding(.vertical, 9)
                            .background(.white.opacity(0.07), in: Capsule())
                    }
                    .foregroundStyle(.primary)
                }
            }
        }
    }
}

struct DamaOnboarding: View {
    @AppStorage("dama.onboardingComplete") private var complete = false
    @State private var name = ""
    @State private var birthDate = Date()
    @State private var language = "de"
    @State private var step = 0
    @Environment(\.dismiss) private var dismiss

    var body: some View {
        NavigationStack {
            VStack(spacing: 24) {
                Text("Dama").font(.system(size: 42, weight: .bold, design: .rounded))
                Text(stepTitle).font(.title2.bold())
                if step == 0 {
                    TextField("Dein Benutzername", text: $name).textFieldStyle(.roundedBorder)
                } else if step == 1 {
                    DatePicker("Geburtsdatum", selection: $birthDate, displayedComponents: .date)
                } else if step == 2 {
                    Picker("Sprache", selection: $language) { Text("Deutsch").tag("de"); Text("English").tag("en") }.pickerStyle(.segmented)
                } else {
                    DamaGlassCard { VStack(alignment: .leading, spacing: 10) { Text("Dama ist bereit.").font(.headline); Text("Du kannst später Stimme, Datenschutz, KI-Modell und Berechtigungen in den Einstellungen ändern.").foregroundStyle(.secondary) } }
                }
                Spacer()
                Button(step == 3 ? "Dama starten" : "Weiter") {
                    if step < 3 { step += 1 } else { complete = true; dismiss() }
                }
                .buttonStyle(.borderedProminent)
                .disabled(step == 0 && name.trimmingCharacters(in: .whitespaces).isEmpty)
            }
            .padding(24)
            .navigationBarTitleDisplayMode(.inline)
        }
    }
    private var stepTitle: String { ["Wie soll ich dich nennen?", "Wann hast du Geburtstag?", "Welche Sprache möchtest du?", "Dama konfigurieren"][step] }
}

struct DamaDeveloperPanel: View {
    @ObservedObject private var settings = DamaSettings.shared
    @State private var testResult = "Noch kein Verbindungstest"
    var body: some View {
        Form {
            Section("Dama") {
                LabeledContent("Version", value: "0.3.0 • Round 2")
                LabeledContent("Modus", value: settings.modelMode.rawValue)
                LabeledContent("Sprache", value: settings.language == "en" ? "English" : "Deutsch")
            }
            Section("Verbindung") {
                LabeledContent("Claude API", value: Keychain.get("apiKey")?.isEmpty == false ? "Konfiguriert" : "Nicht konfiguriert")
                Button("Verbindung testen") { testResult = Keychain.get("apiKey")?.isEmpty == false ? "API-Key gefunden" : "Kein API-Key im Schlüsselbund" }
                Text(testResult).font(.caption).foregroundStyle(.secondary)
            }
        }
        .navigationTitle("Entwickler")
    }
}

struct DamaThemeSettingsView: View {
    @ObservedObject private var settings = DamaSettings.shared
    var body: some View {
        Form {
            Section("Darstellung") {
                Picker("Theme", selection: $settings.theme) { ForEach(DamaTheme.allCases) { Text($0.rawValue).tag($0) } }
                Picker("Akzentfarbe", selection: $settings.accent) { ForEach(DamaAccent.allCases) { Text($0.rawValue.capitalized).tag($0) } }
                Toggle("Animationen", isOn: $settings.animations)
            }
            Section("Privatsphäre") {
                Toggle("Privater Chat", isOn: $settings.privateChat)
                Toggle("App-Schutz", isOn: $settings.biometricLock)
            }
        }
        .navigationTitle("Darstellung & Sicherheit")
    }
}

struct DamaModelPickerView: View {
    @ObservedObject private var settings = DamaSettings.shared
    var body: some View {
        List(DamaModelMode.allCases) { mode in
            Button { settings.modelMode = mode } label: {
                HStack { VStack(alignment: .leading) { Text(mode.rawValue).font(.headline); Text(mode.subtitle).font(.caption).foregroundStyle(.secondary) }; Spacer(); if settings.modelMode == mode { Image(systemName: "checkmark.circle.fill") } }
            }
            .foregroundStyle(.primary)
        }
        .navigationTitle("KI-Modell")
    }
}

struct DamaFilePicker: UIViewControllerRepresentable {
    let onPicked: ([URL]) -> Void
    func makeCoordinator() -> Coordinator { Coordinator(onPicked: onPicked) }
    func makeUIViewController(context: Context) -> UIDocumentPickerViewController {
        let picker = UIDocumentPickerViewController(forOpeningContentTypes: [.pdf, .plainText, .image, .data], asCopy: true)
        picker.allowsMultipleSelection = true
        picker.delegate = context.coordinator
        return picker
    }
    func updateUIViewController(_ uiViewController: UIDocumentPickerViewController, context: Context) {}
    final class Coordinator: NSObject, UIDocumentPickerDelegate {
        let onPicked: ([URL]) -> Void
        init(onPicked: @escaping ([URL]) -> Void) { self.onPicked = onPicked }
        func documentPicker(_ controller: UIDocumentPickerViewController, didPickDocumentsAt urls: [URL]) { onPicked(urls) }
    }
}
