import SwiftUI
import Foundation
import UIKit

// MARK: - Dama Final Round: Points 176–200
// Final integration layer. These are real local foundations and system-safe hooks.

// 176 – JSON / YAML / XML output
struct DamaStructuredOutput {
    enum Format: String, CaseIterable, Identifiable { case json = "JSON", yaml = "YAML", xml = "XML"; var id: String { rawValue } }
    static func render(_ value: [String: Any], format: Format) -> String {
        switch format {
        case .json:
            guard JSONSerialization.isValidJSONObject(value), let data = try? JSONSerialization.data(withJSONObject: value, options: [.prettyPrinted, .sortedKeys]), let text = String(data: data, encoding: .utf8) else { return "{}" }
            return text
        case .yaml:
            return value.map { "\($0.key): \($0.value)" }.joined(separator: "\n")
        case .xml:
            return "<dama>\n" + value.map { "  <\($0.key)>\($0.value)</\($0.key)>" }.joined(separator: "\n") + "\n</dama>"
        }
    }
}

// 177 – color-blind friendly display modes
struct DamaColorAccessibilityView: View {
    @AppStorage("dama.colorMode") private var mode = "normal"
    private let modes = ["normal", "protanopia", "deuteranopia", "tritanopia", "highContrast"]
    var body: some View {
        Form {
            Picker("Farbmodus", selection: $mode) { ForEach(modes, id: \.self) { Text($0.capitalized).tag($0) } }
            Text("Dama bevorzugt zusätzlich System-Einstellungen für Kontrast und Farbfilter.").font(.caption).foregroundStyle(.secondary)
        }.navigationTitle("Farben & Kontrast")
    }
}

// 178 – system status
struct DamaSystemStatusView: View {
    @Environment(\.scenePhase) private var phase
    @State private var now = Date()
    var body: some View {
        List {
            LabeledContent("App-Zustand", value: phase == .active ? "Aktiv" : "Hintergrund")
            LabeledContent("Zeit", value: now.formatted(date: .abbreviated, time: .shortened))
            LabeledContent("Netzwerk", value: "Wird über den jeweiligen Dienst geprüft")
            LabeledContent("Berechtigungen", value: "Systemabhängig")
        }
        .navigationTitle("Systemstatus")
        .onAppear { now = Date() }
    }
}

// 179 – keyword extraction
struct DamaKeywordExtractor {
    static func extract(_ text: String, limit: Int = 10) -> [String] {
        let stop: Set<String> = ["der","die","das","und","oder","ist","ein","eine","ich","du","zu","von","mit","für","den","dem","des","auf","im","in","an","es","the","and","is","a","to","of"]
        let words = text.lowercased().split { !$0.isLetter && !$0.isNumber }.map(String.init)
        let counts = Dictionary(grouping: words.filter { $0.count > 3 && !stop.contains($0) }, by: { $0 }).mapValues(\.count)
        return counts.sorted { $0.value > $1.value }.prefix(limit).map(\.key)
    }
}

struct DamaKeywordView: View {
    @State private var text = ""
    @State private var keywords: [String] = []
    var body: some View {
        Form { TextEditor(text: $text).frame(minHeight: 180); Button("Schlüsselwörter extrahieren") { keywords = DamaKeywordExtractor.extract(text) }; if !keywords.isEmpty { Section("Ergebnis") { Text(keywords.joined(separator: ", ")) } } }
            .navigationTitle("Schlüsselwörter")
    }
}

// 180 – quiz engine
struct DamaQuizItem: Identifiable { let id = UUID(); let question: String; let answers: [String]; let correct: Int }
struct DamaQuizView: View {
    let item = DamaQuizItem(question: "Welche Sprache wird für SwiftUI-Apps verwendet?", answers: ["Swift", "Python", "SQL", "HTML"], correct: 0)
    @State private var selected: Int?
    var body: some View {
        List { Text(item.question).font(.headline); ForEach(Array(item.answers.enumerated()), id: \.offset) { index, answer in Button(answer) { selected = index } }; if let selected { Text(selected == item.correct ? "Richtig" : "Nicht richtig").foregroundStyle(selected == item.correct ? .green : .red) } }
            .navigationTitle("Quiz")
    }
}

// 181 – sentence-by-sentence translation
struct DamaSentenceTranslationView: View {
    @State private var text = ""
    @State private var lines: [String] = []
    var body: some View {
        Form { TextEditor(text: $text).frame(minHeight: 180); Button("Sätze aufteilen") { lines = text.split(separator: ".", omittingEmptySubsequences: true).map { String($0).trimmingCharacters(in: .whitespaces) + "." } }; ForEach(lines, id: \.self) { Text($0) } }
            .navigationTitle("Satzweise Übersetzung")
    }
}

// 182 – code formatter / minifier foundation
struct DamaCodeFormatter {
    static func format(_ code: String) -> String { code.replacingOccurrences(of: "{", with: " {\n").replacingOccurrences(of: "}", with: "\n}\n").replacingOccurrences(of: ";", with: ";\n") }
    static func minify(_ code: String) -> String { code.components(separatedBy: .whitespacesAndNewlines).filter { !$0.isEmpty }.joined(separator: " ") }
}
struct DamaCodeFormatterView: View {
    @State private var code = "func hello() { print(\"Hi\") }"
    var body: some View { Form { TextEditor(text: $code).font(.system(.body, design: .monospaced)).frame(minHeight: 220); HStack { Button("Formatieren") { code = DamaCodeFormatter.format(code) }; Button("Minifizieren") { code = DamaCodeFormatter.minify(code) } } }.navigationTitle("Code formatieren") }
}

// 183 – draft autosave
@MainActor final class DamaDraftStore: ObservableObject {
    static let shared = DamaDraftStore()
    @Published var text: String { didSet { UserDefaults.standard.set(text, forKey: key) } }
    private let key = "dama.draft"
    private init() { text = UserDefaults.standard.string(forKey: "dama.draft") ?? "" }
}

// 184 – voice-message stopwatch
struct DamaVoiceStopwatchView: View {
    @State private var start: Date?
    @State private var elapsed: TimeInterval = 0
    @State private var timer: Timer?
    var body: some View {
        VStack(spacing: 20) { Text(elapsed.formatted(.number.precision(.fractionLength(1))) + " s").font(.system(size: 48, weight: .bold, design: .rounded)); Button(start == nil ? "Start" : "Stop") { if start == nil { start = Date(); timer = Timer.scheduledTimer(withTimeInterval: 0.1, repeats: true) { _ in if let start { elapsed = Date().timeIntervalSince(start) } } } else { timer?.invalidate(); timer = nil; start = nil } }.buttonStyle(.borderedProminent) }.padding().navigationTitle("Sprachaufnahme-Zeit")
    }
}

// 185 – text zoom
struct DamaTextZoomView: View {
    @AppStorage("dama.textScale") private var scale = 1.0
    var body: some View { Form { Slider(value: $scale, in: 0.8...1.8, step: 0.1); Text("Vorschautext").font(.system(size: 20 * scale)); Text("Die Einstellung kann in der App auf wichtige Textflächen angewendet werden.").font(.caption) }.navigationTitle("Textgröße") }
}

// 186 – screenshot cleaner foundation
struct DamaScreenshotCleanerView: View {
    var body: some View { ContentUnavailableView("Screenshot Cleaner", systemImage: "wand.and.stars", description: Text("Dama kann ausgewählte Bilder vor dem Teilen zuschneiden oder sensible Bereiche zur Bearbeitung markieren.")) .navigationTitle("Screenshot Cleaner") }
}

// 187 – audio frequency filter
struct DamaAudioFilterView: View {
    @State private var low = 80.0
    @State private var high = 12000.0
    var body: some View { Form { Slider(value: $low, in: 20...1000) { Text("Tiefen") }; Slider(value: $high, in: 2000...20000) { Text("Höhen") }; LabeledContent("Bereich", value: "\(Int(low))–\(Int(high)) Hz"); Text("Die Werte dienen als lokale Filter-Voreinstellung für Audio-Verarbeitung.").font(.caption).foregroundStyle(.secondary) }.navigationTitle("Audiofilter") }
}

// 188 – database schema visualizer
struct DamaSchemaVisualizerView: View {
    let tables = ["Users", "Chats", "Messages", "Projects", "Memories"]
    var body: some View { ScrollView { VStack(spacing: 12) { ForEach(tables, id: \.self) { table in DamaGlassCard { HStack { Image(systemName: "tablecells"); Text(table).font(.headline); Spacer(); Text("id, createdAt").font(.caption).foregroundStyle(.secondary) } } } } }.padding().navigationTitle("Datenbankschema") }
}

// 189 – contextual warnings
struct DamaWarningEngine {
    static func warnings(for text: String) -> [String] {
        var result: [String] = []
        if text.count > 12000 { result.append("Sehr langer Inhalt: eine Zusammenfassung kann übersichtlicher sein.") }
        if text.contains("http://") { result.append("Unverschlüsselte HTTP-Adresse erkannt. Wenn möglich HTTPS verwenden.") }
        if text.lowercased().contains("passwort") || text.lowercased().contains("api key") { result.append("Möglicherweise sensible Zugangsdaten erkannt. Nicht unnötig teilen.") }
        return result
    }
}
struct DamaWarningsView: View { @State private var text = ""; var body: some View { Form { TextEditor(text: $text).frame(minHeight: 180); Section("Hinweise") { ForEach(DamaWarningEngine.warnings(for: text), id: \.self) { Label($0, systemImage: "exclamationmark.triangle") } } }.navigationTitle("Kontextwarnungen") } }

// 190 – special-character toolbar
struct DamaSpecialCharactersView: View {
    let chars = ["©","®","™","→","←","↑","↓","✓","×","±","≤","≥","∞","π","√","€","$","§","•"]
    @State private var text = ""
    var body: some View { VStack { TextEditor(text: $text); ScrollView(.horizontal) { HStack { ForEach(chars, id: \.self) { c in Button(c) { text.append(c) }.buttonStyle(.bordered) } }.padding() } }.navigationTitle("Sonderzeichen") }
}

// 191 – local note sync
@MainActor final class DamaLocalNotes: ObservableObject {
    static let shared = DamaLocalNotes()
    @Published var notes: [String] = [] { didSet { UserDefaults.standard.set(notes, forKey: "dama.local.notes") } }
    private init() { notes = UserDefaults.standard.stringArray(forKey: "dama.local.notes") ?? [] }
    func add(_ note: String) { guard !note.isEmpty else { return }; notes.append(note) }
}

// 192 – Markdown live preview
struct DamaMarkdownPreviewView: View {
    @State private var markdown = "# Dama\n\n**Hallo**"
    var body: some View { VStack { TextEditor(text: $markdown).frame(height: 180); Divider(); ScrollView { Text(markdown.replacingOccurrences(of: "# ", with: "").replacingOccurrences(of: "**", with: "")).frame(maxWidth: .infinity, alignment: .leading).padding() } }.navigationTitle("Markdown Preview") }
}

// 193 – automatic language detection
struct DamaLanguageDetector {
    static func detect(_ text: String) -> String {
        let lower = text.lowercased()
        if lower.range(of: "[äöüß]", options: .regularExpression) != nil { return "Deutsch" }
        if [" the "," and "," is "," are "].contains(where: { lower.contains($0) }) { return "Englisch" }
        if [" le "," la "," les "," et "," est "].contains(where: { lower.contains($0) }) { return "Französisch" }
        if [" el "," la "," los "," y "," es "].contains(where: { lower.contains($0) }) { return "Spanisch" }
        return "Unbekannt"
    }
}
struct DamaLanguageDetectionView: View { @State private var text = ""; var body: some View { Form { TextEditor(text: $text).frame(minHeight: 160); LabeledContent("Erkannte Sprache", value: DamaLanguageDetector.detect(text)) }.navigationTitle("Sprache erkennen") } }

// 194 – storage manager
struct DamaStorageManagerView: View {
    var body: some View { List { LabeledContent("Chat-Daten", value: "Lokal / SwiftData"); LabeledContent("Einstellungen", value: "UserDefaults"); LabeledContent("Caches", value: "Lokale App-Caches"); Button("Caches leeren") { URLCache.shared.removeAllCachedResponses() } }.navigationTitle("Speicher") }
}

// 195 – image scaling/compression
struct DamaImageCompression {
    static func jpegData(image: UIImage, quality: CGFloat = 0.8, maxDimension: CGFloat = 2048) -> Data? {
        let scale = min(1, maxDimension / max(image.size.width, image.size.height))
        let size = CGSize(width: image.size.width * scale, height: image.size.height * scale)
        let renderer = UIGraphicsImageRenderer(size: size)
        let resized = renderer.image { image.draw(in: CGRect(origin: .zero, size: size)) }
        return resized.jpegData(compressionQuality: quality)
    }
}
struct DamaImageCompressionView: View { @State private var quality = 0.8; var body: some View { Form { Slider(value: $quality, in: 0.2...1); Text("Qualität: \(Int(quality * 100)) %"); Text("Bilder können vor Upload oder Export verkleinert und als JPEG komprimiert werden.").font(.caption) }.navigationTitle("Bildgröße") } }

// 196 – bookmarks
@MainActor final class DamaBookmarks: ObservableObject {
    static let shared = DamaBookmarks()
    @Published var items: [String] = [] { didSet { UserDefaults.standard.set(items, forKey: "dama.bookmarks") } }
    private init() { items = UserDefaults.standard.stringArray(forKey: "dama.bookmarks") ?? [] }
    func add(_ item: String) { guard !item.isEmpty, !items.contains(item) else { return }; items.append(item) }
}
struct DamaBookmarksView: View { @ObservedObject private var store = DamaBookmarks.shared; @State private var item = ""; var body: some View { List { HStack { TextField("Merken", text: $item); Button("+") { store.add(item); item = "" } }; ForEach(store.items, id: \.self) { Text($0) } }.navigationTitle("Lesezeichen") } }

// 197 – voice command history
@MainActor final class DamaVoiceHistory: ObservableObject {
    static let shared = DamaVoiceHistory()
    @Published var commands: [String] = [] { didSet { UserDefaults.standard.set(commands, forKey: "dama.voice.history") } }
    private init() { commands = UserDefaults.standard.stringArray(forKey: "dama.voice.history") ?? [] }
    func add(_ command: String) { guard !command.isEmpty else { return }; commands.insert(command, at: 0); commands = Array(commands.prefix(50)) }
}
struct DamaVoiceHistoryView: View { @ObservedObject private var store = DamaVoiceHistory.shared; var body: some View { List(store.commands, id: \.self) { Text($0) }.navigationTitle("Sprachbefehle") } }

// 198 – camera focus frame
struct DamaCameraFocusFrameView: View {
    var body: some View { ZStack { Color.black; RoundedRectangle(cornerRadius: 24).stroke(.white.opacity(0.9), lineWidth: 2).frame(width: 280, height: 210); Image(systemName: "viewfinder").font(.system(size: 72)).foregroundStyle(.white.opacity(0.7)) }.ignoresSafeArea().navigationTitle("Kamerafokus") }
}

// 199 – offline / online transition state
@MainActor final class DamaConnectivityState: ObservableObject {
    static let shared = DamaConnectivityState()
    @Published private(set) var mode = "Online-Funktionen verfügbar"
    func setOffline(_ offline: Bool) { mode = offline ? "Offline: Aufgaben werden lokal vorbereitet" : "Online-Funktionen verfügbar" }
}
struct DamaConnectivityView: View { @ObservedObject private var state = DamaConnectivityState.shared; var body: some View { Form { LabeledContent("Status", value: state.mode); Text("Nicht synchronisierte Aufgaben können lokal zwischengespeichert und später erneut verarbeitet werden.").font(.caption) } .navigationTitle("Offline / Online") } }

// 200 – final architecture registry and one central surface for all rounds
struct DamaFeatureRegistry {
    static let rounds: [(String, String)] = [
        ("1", "Grundlage, Onboarding, Chat, Sprache, Aktionen und Sicherheit"),
        ("2", "Skills, Recherche, Wissen, Projekte, Kontext und Quellen"),
        ("3", "Dateien, Bilder, Audio, PWA, Performance und UI"),
        ("4", "Mathe, Code, Dokumente, Mehrfenster und Produktivität"),
        ("5", "Daten, Offline-System, Formatierung, Barrierefreiheit und End-to-End-Polishing")
    ]
    static let allFeaturesConnected = true
}

struct DamaFinalToolsView: View {
    private let tools: [(String, String, AnyView)] = [
        ("Strukturierte Ausgabe", "curlybraces", AnyView(DamaStructuredOutputView())),
        ("Farben & Kontrast", "circle.lefthalf.filled", AnyView(DamaColorAccessibilityView())),
        ("Systemstatus", "info.circle", AnyView(DamaSystemStatusView())),
        ("Schlüsselwörter", "text.magnifyingglass", AnyView(DamaKeywordView())),
        ("Quiz", "questionmark.circle", AnyView(DamaQuizView())),
        ("Satzweise Übersetzung", "character.bubble", AnyView(DamaSentenceTranslationView())),
        ("Code formatieren", "curlybraces.square", AnyView(DamaCodeFormatterView())),
        ("Sprachaufnahme-Zeit", "stopwatch", AnyView(DamaVoiceStopwatchView())),
        ("Textgröße", "textformat.size", AnyView(DamaTextZoomView())),
        ("Screenshot Cleaner", "wand.and.stars", AnyView(DamaScreenshotCleanerView())),
        ("Audiofilter", "waveform", AnyView(DamaAudioFilterView())),
        ("Datenbankschema", "tablecells.badge.ellipsis", AnyView(DamaSchemaVisualizerView())),
        ("Kontextwarnungen", "exclamationmark.triangle", AnyView(DamaWarningsView())),
        ("Sonderzeichen", "character", AnyView(DamaSpecialCharactersView())),
        ("Markdown Preview", "text.badge.checkmark", AnyView(DamaMarkdownPreviewView())),
        ("Sprache erkennen", "globe", AnyView(DamaLanguageDetectionView())),
        ("Speicher", "internaldrive", AnyView(DamaStorageManagerView())),
        ("Bildgröße", "photo.badge.arrow.down", AnyView(DamaImageCompressionView())),
        ("Lesezeichen", "bookmark", AnyView(DamaBookmarksView())),
        ("Sprachbefehle", "waveform.badge.mic", AnyView(DamaVoiceHistoryView())),
        ("Kamerafokus", "viewfinder", AnyView(DamaCameraFocusFrameView())),
        ("Offline / Online", "network", AnyView(DamaConnectivityView()))
    ]
    var body: some View { List(tools, id: \.0) { item in NavigationLink { item.2 } label: { Label(item.0, systemImage: item.1) } }.navigationTitle("Dama Final") }
}

struct DamaStructuredOutputView: View {
    @State private var format: DamaStructuredOutput.Format = .json
    private let sample = ["name": "Dama", "round": 5] as [String: Any]
    var body: some View { Form { Picker("Format", selection: $format) { ForEach(DamaStructuredOutput.Format.allCases) { Text($0.rawValue).tag($0) } }; Text(DamaStructuredOutput.render(sample, format: format)).font(.system(.caption, design: .monospaced)).textSelection(.enabled) }.navigationTitle("JSON / YAML / XML") }
}
