import SwiftUI
import SwiftData

struct MemoriesView: View {
    @Environment(\.modelContext) private var ctx
    @Query(sort: \Memory.createdAt, order: .reverse) private var memories: [Memory]
    @State private var adding = false
    @State private var newText = ""
    @State private var confirmReset = false

    var body: some View {
        NavigationStack {
            List {
                ForEach(memories) { m in
                    VStack(alignment: .leading, spacing: 2) {
                        Text(m.text)
                        Text(m.createdAt.formatted(date: .abbreviated, time: .shortened))
                            .font(.caption).foregroundStyle(.secondary)
                    }
                }
                .onDelete { idx in idx.forEach { ctx.delete(memories[$0]) }; try? ctx.save() }
            }
            .overlay {
                if memories.isEmpty {
                    ContentUnavailableView("Noch nichts gespeichert", systemImage: "brain",
                                           description: Text("Sag zum Beispiel: „Dama, merk dir, dass ich Kaffee ohne Zucker trinke.“"))
                }
            }
            .navigationTitle("Erinnerungen")
            .toolbar {
                ToolbarItem(placement: .topBarLeading) {
                    if !memories.isEmpty { Button("Zurücksetzen", role: .destructive) { confirmReset = true } }
                }
                ToolbarItem(placement: .topBarTrailing) { Button { adding = true } label: { Image(systemName: "plus") } }
            }
            .alert("Neue Erinnerung", isPresented: $adding) {
                TextField("Was soll Dama wissen?", text: $newText)
                Button("Speichern") {
                    let t = newText.trimmingCharacters(in: .whitespacesAndNewlines)
                    if !t.isEmpty { ctx.insert(Memory(text: t)); try? ctx.save() }
                    newText = ""
                }
                Button("Abbrechen", role: .cancel) { newText = "" }
            }
            .confirmationDialog("Gesamten Speicher löschen?", isPresented: $confirmReset, titleVisibility: .visible) {
                Button("Alles löschen", role: .destructive) { memories.forEach { ctx.delete($0) }; try? ctx.save() }
            }
        }
    }
}

struct SettingsView: View {
    @EnvironmentObject var a: Assistant
    @Environment(\.modelContext) private var ctx
    @Query private var memories: [Memory]

    @AppStorage("rate") private var rate = 0.5
    @AppStorage("speakReplies") private var speakReplies = true
    @AppStorage("language") private var language = "auto"
    @AppStorage("wakeEnabled") private var wake = false
    @AppStorage("conversationMode") private var conversationMode = false
    @AppStorage("memoryEnabled") private var memoryEnabled = true
    @AppStorage("webSearch") private var webSearch = true
    @State private var key = Keychain.get("apiKey") ?? ""
    @State private var confirmWipe = false

    var body: some View {
        NavigationStack {
            Form {
                Section("Dama") {
                    NavigationLink("Skills") { DamaSkillLibraryView() }
                    NavigationLink("Globale Suche") { DamaGlobalSearchView() }
                    NavigationLink("Ordner & Projekte") { DamaFoldersView() }
                    NavigationLink("Kontext & Quellen") { DamaContextInfoView() }
                    NavigationLink("Benachrichtigungen") { DamaNotificationCenterView() }
                    NavigationLink("Entwicklerbereich") { DamaDeveloperPanel() }
                    NavigationLink("Design & Modell") { DamaThemeSettingsView() }
                    NavigationLink("KI-Modell") { DamaModelPickerView() }
                }
                Section("Verbindung") {
                    SecureField("Anthropic-API-Schlüssel", text: $key)
                        .textContentType(.password).autocorrectionDisabled()
                        .onChange(of: key) { _, v in Keychain.set("apiKey", v) }
                    Text("Wird nur im iOS-Schlüsselbund gespeichert.").font(.caption).foregroundStyle(.secondary)
                    Toggle("Websuche für aktuelle Infos", isOn: $webSearch)
                }
                Section("Stimme & Sprache") {
                    Toggle("Antworten vorlesen", isOn: $speakReplies)
                    VStack(alignment: .leading) {
                        Text("Sprechtempo")
                        Slider(value: $rate, in: 0.35...0.6)
                    }
                    Picker("Sprache", selection: $language) {
                        Text("Automatisch").tag("auto"); Text("Deutsch").tag("de"); Text("English").tag("en")
                    }
                    Text("Tipp: Lade unter iOS-Einstellungen › Bedienungshilfen › Gesprochene Inhalte › Stimmen eine „Erweitert“-Stimme (z. B. Markus), dann nutzt Dama sie automatisch.")
                        .font(.caption).foregroundStyle(.secondary)
                }
                Section("Aktivierung") {
                    Toggle("„Hey Dama“ bei geöffneter App", isOn: $wake)
                    Toggle("Gesprächsmodus (hört nach Antwort weiter zu)", isOn: $conversationMode)
                    Text("iOS erlaubt Apps keinen Dauer-Mikrofonbetrieb im Hintergrund. Starte Dama außerhalb der App über Siri („Hey Siri, öffne Dama“), die Action-Taste, Zurücktippen oder den Kurzbefehl „Dama zuhören“.")
                        .font(.caption).foregroundStyle(.secondary)
                }
                Section("Speicher") {
                    Toggle("Gedächtnis aktiv", isOn: $memoryEnabled)
                    LabeledContent("Gespeicherte Erinnerungen", value: "\(memories.count)")
                }
                Section("Datenschutz") {
                    Text("Mikrofon, Spracherkennung, Kalender, Erinnerungen und Kontakte werden erst abgefragt, wenn du eine entsprechende Funktion nutzt. Anrufe, Kurzbefehle und fremde Apps werden nur nach deiner Bestätigung geöffnet. Nachrichten sendest du selbst per Tipp ab. Deine Anfragen werden zur Beantwortung an Anthropic gesendet; Verlauf und Erinnerungen liegen lokal auf dem Gerät.")
                        .font(.caption)
                    Button("iOS-Berechtigungen verwalten") {
                        if let u = URL(string: UIApplication.openSettingsURLString) { UIApplication.shared.open(u) }
                    }
                    Button("Alle Gespräche löschen", role: .destructive) { confirmWipe = true }
                }
            }
            .navigationTitle("Einstellungen")
            .confirmationDialog("Alle Gespräche löschen?", isPresented: $confirmWipe, titleVisibility: .visible) {
                Button("Löschen", role: .destructive) {
                    try? ctx.delete(model: Conversation.self); try? ctx.save(); a.current = nil
                }
            }
        }
    }
}
