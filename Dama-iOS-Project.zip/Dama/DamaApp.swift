import SwiftUI
import SwiftData

@main
struct DamaApp: App {
    @StateObject private var speech: SpeechService
    @StateObject private var assistant: Assistant

    init() {
        let s = SpeechService()
        _speech = StateObject(wrappedValue: s)
        _assistant = StateObject(wrappedValue: Assistant(speech: s))
    }

    var body: some Scene {
        WindowGroup {
            RootView()
                .environmentObject(speech)
                .environmentObject(assistant)
                .preferredColorScheme(nil)
                .environmentObject(DamaSettings.shared)
                .modelContainer(Persistence.shared)
        }
    }
}

struct RootView: View {
    @AppStorage("dama.onboardingComplete") private var onboardingComplete = false
    @EnvironmentObject var a: Assistant
    @Environment(\.scenePhase) private var phase
    @AppStorage("wakeEnabled") private var wake = false

    var body: some View {
        if !onboardingComplete {
            DamaOnboarding()
        } else {
        TabView {
            DamaHomeView().tabItem { Label("Dama", systemImage: "circle.hexagongrid.fill") }
            HistoryView().tabItem { Label("Verlauf", systemImage: "bubble.left.and.bubble.right") }
            MemoriesView().tabItem { Label("Erinnerungen", systemImage: "brain") }
            SettingsView().tabItem { Label("Einstellungen", systemImage: "gearshape") }
        }
        .tint(.cyan)
        .onAppear { a.appBecameActive(wake: wake) }
        .onChange(of: phase) { _, p in
            if p == .active { a.appBecameActive(wake: wake) } else { a.appWentBackground() }
        }
        .onChange(of: wake) { _, v in a.setWake(v) }
        }
    }
}
