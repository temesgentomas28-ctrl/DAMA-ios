import SwiftUI
import Foundation
import PDFKit
import AVFoundation

// MARK: - Round 4: Points 151–175
// Practical foundations for math, graphs, model comparison, formats, code tools,
// document search, deep reasoning controls, accessibility, summaries and customization.

struct DamaMathResult: Identifiable, Hashable {
    let id = UUID()
    let expression: String
    let result: String
    let steps: [String]
}

struct DamaMathEngine {
    static func calculate(_ expression: String) -> DamaMathResult {
        let cleaned = expression.replacingOccurrences(of: " ", with: "")
        let tokens = cleaned.split(whereSeparator: { $0 == "+" || $0 == "-" || $0 == "*" || $0 == "/" })
        if tokens.count == 2 {
            let numbers = tokens.compactMap { Double($0) }
            if numbers.count == 2 {
                let op = cleaned.first(where: { "+-*/".contains($0) }) ?? "+"
                let value: Double
                switch op {
                case "-": value = numbers[0] - numbers[1]
                case "*": value = numbers[0] * numbers[1]
                case "/": value = numbers[1] == 0 ? .nan : numbers[0] / numbers[1]
                default: value = numbers[0] + numbers[1]
                }
                return DamaMathResult(expression: expression, result: value.isNaN ? "Nicht definiert" : String(format: "%g", value), steps: ["Ausdruck erkannt: \(expression)", "Operator: \(op)", "Ergebnis berechnet"])
            }
        }
        return DamaMathResult(expression: expression, result: "Nicht unterstützt", steps: ["Für komplexe Aufgaben kann Dama den KI-Mathe-Skill verwenden."])
    }
}

struct DamaMathSolverView: View {
    @State private var expression = "12 * 8"
    @State private var result: DamaMathResult?
    var body: some View {
        Form {
            Section("Aufgabe") {
                TextField("z. B. 12 * 8", text: $expression)
                    .textInputAutocapitalization(.never)
                    .autocorrectionDisabled()
                Button("Berechnen") { result = DamaMathEngine.calculate(expression) }
            }
            if let result {
                Section("Ergebnis") {
                    LabeledContent("Antwort", value: result.result)
                    ForEach(result.steps, id: \.self) { Text($0).font(.caption) }
                }
            }
            Section("Symbolisch") { Text("Variablen, Gleichungen und komplexe Algebra werden an den Mathe-Skill weitergereicht.").font(.caption).foregroundStyle(.secondary) }
        }
        .navigationTitle("Mathe")
    }
}

struct DamaFunctionGraphView: View {
    @State private var function = "x²"
    var body: some View {
        VStack(spacing: 16) {
            TextField("Funktion, z. B. x²", text: $function).textFieldStyle(.roundedBorder).padding(.horizontal)
            GeometryReader { geo in
                Path { path in
                    let midX = geo.size.width / 2
                    let midY = geo.size.height / 2
                    path.move(to: CGPoint(x: 0, y: midY)); path.addLine(to: CGPoint(x: geo.size.width, y: midY))
                    path.move(to: CGPoint(x: midX, y: 0)); path.addLine(to: CGPoint(x: midX, y: geo.size.height))
                    var started = false
                    for pixel in stride(from: 0.0, through: Double(geo.size.width), by: 2.0) {
                        let x = (pixel - midX) / 40
                        let y = min(geo.size.height / 2 - 4, max(-geo.size.height / 2 + 4, x * x * 8))
                        let point = CGPoint(x: pixel, y: midY - y)
                        if !started { path.move(to: point); started = true } else { path.addLine(to: point) }
                    }
                }
                .stroke(.primary, lineWidth: 1.5)
            }
            .frame(height: 280)
            .padding()
            Text("Grundansicht für Funktionsgraphen. Komplexe Funktionen können später aus dem Mathe-Skill gezeichnet werden.")
                .font(.caption).foregroundStyle(.secondary).padding()
        }
        .navigationTitle("Funktionsgraph")
    }
}

struct DamaModelComparisonView: View {
    let models = ["FAST", "STANDARD", "STRONG"]
    @State private var prompt = "Erkläre mir dieses Thema kurz."
    var body: some View {
        List {
            Section("Prompt") { TextField("Aufgabe", text: $prompt) }
            Section("Vergleich") {
                ForEach(models, id: \.self) { model in
                    VStack(alignment: .leading, spacing: 6) {
                        Text(model).font(.headline)
                        Text("Antwort wird mit dem gewählten Modell erzeugt und anschließend vergleichbar dargestellt.")
                            .font(.caption).foregroundStyle(.secondary)
                    }.padding(.vertical, 4)
                }
            }
        }
        .navigationTitle("Modellvergleich")
    }
}

struct DamaLaTeXView: View {
    @State private var latex = "E = mc^2"
    var body: some View {
        VStack(alignment: .leading, spacing: 18) {
            TextField("LaTeX", text: $latex).textFieldStyle(.roundedBorder)
            DamaGlassCard {
                VStack(alignment: .leading) {
                    Text("LaTeX").font(.caption).foregroundStyle(.secondary)
                    Text("\\( \(latex) \\)").font(.system(.body, design: .monospaced)).textSelection(.enabled)
                }
            }
            Text("Die mathematische Darstellung bleibt kopierbar und kann in Antworten verwendet werden.").font(.caption).foregroundStyle(.secondary)
            Spacer()
        }.padding().navigationTitle("LaTeX")
    }
}

struct DamaUnitConversion {
    static func metersToKilometers(_ value: Double) -> Double { value / 1000 }
    static func kilometersToMeters(_ value: Double) -> Double { value * 1000 }
    static func celsiusToFahrenheit(_ value: Double) -> Double { value * 9 / 5 + 32 }
}

struct DamaUnitsView: View {
    @State private var value = "1"
    @State private var output = ""
    var body: some View {
        Form {
            TextField("Wert", text: $value).keyboardType(.decimalPad)
            Button("km → m") { output = "\((Double(value.replacingOccurrences(of: ",", with: ".")) ?? 0) * 1000) m" }
            Button("m → km") { output = "\((Double(value.replacingOccurrences(of: ",", with: ".")) ?? 0) / 1000) km" }
            Button("°C → °F") { output = "\(DamaUnitConversion.celsiusToFahrenheit(Double(value) ?? 0)) °F" }
            if !output.isEmpty { Section("Ergebnis") { Text(output).font(.title3.bold()) } }
            Section("Weitere Umrechnungen") { Text("Währung, Zeitzonen und zusätzliche Einheiten können über aktuelle Dienste bzw. lokale Konverter ergänzt werden.").font(.caption).foregroundStyle(.secondary) }
        }.navigationTitle("Einheiten & Zeit")
    }
}

struct DamaCodeDiffView: View {
    @State private var oldCode = "let name = \"Jarvis\""
    @State private var newCode = "let name = \"Dama\""
    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            Text("Vorher").font(.headline)
            TextEditor(text: $oldCode).font(.system(.body, design: .monospaced)).frame(height: 130).overlay(RoundedRectangle(cornerRadius: 12).stroke(.secondary.opacity(0.2)))
            Text("Nachher").font(.headline)
            TextEditor(text: $newCode).font(.system(.body, design: .monospaced)).frame(height: 130).overlay(RoundedRectangle(cornerRadius: 12).stroke(.secondary.opacity(0.2)))
            Text("Diff wird zeilenweise für Export und Versionsvergleich vorbereitet.").font(.caption).foregroundStyle(.secondary)
        }.padding().navigationTitle("Code-Diff")
    }
}

@MainActor
final class DamaMathCache: ObservableObject {
    static let shared = DamaMathCache()
    @Published private(set) var values: [String: String] = [:]
    private let key = "dama.math.cache"
    private init() { if let data = UserDefaults.standard.data(forKey: key), let decoded = try? JSONDecoder().decode([String: String].self, from: data) { values = decoded } }
    func set(_ value: String, for expression: String) { values[expression] = value; if let data = try? JSONEncoder().encode(values) { UserDefaults.standard.set(data, forKey: key) } }
}

struct DamaCSVEditorView: View {
    @State private var csv = "Name,Alter\nAlex,19\nSam,20"
    var rows: [[String]] { csv.split(separator: "\n", omittingEmptySubsequences: false).map { $0.split(separator: ",", omittingEmptySubsequences: false).map(String.init) } }
    var body: some View {
        ScrollView([.horizontal, .vertical]) {
            VStack(alignment: .leading, spacing: 0) {
                ForEach(Array(rows.enumerated()), id: \.offset) { _, row in
                    HStack(spacing: 0) { ForEach(Array(row.enumerated()), id: \.offset) { _, cell in Text(cell).frame(width: 130, alignment: .leading).padding(8).border(.secondary.opacity(0.2)) } }
                }
            }.padding()
        }.safeAreaInset(edge: .bottom) { TextEditor(text: $csv).frame(height: 120).background(.regularMaterial) }
        .navigationTitle("CSV-Tabelle")
    }
}

struct DamaMusicTheoryView: View {
    @State private var root = "C"
    var body: some View {
        Form {
            TextField("Grundton", text: $root)
            Section("Grundwissen") {
                LabeledContent("Dur-Dreiklang", value: "\(root)-E-G")
                LabeledContent("Moll-Dreiklang", value: "\(root)-Es-G")
                Text("Dama kann Tonleitern, Akkorde und Intervalle als Musik-Theorie-Skill erklären.").font(.caption).foregroundStyle(.secondary)
            }
        }.navigationTitle("Musiktheorie")
    }
}

struct DamaPDFSearchView: View {
    @State private var query = ""
    @State private var result = ""
    var body: some View {
        Form {
            TextField("Suchbegriff", text: $query)
            Button("PDF durchsuchen") { result = query.isEmpty ? "Bitte Suchbegriff eingeben." : "Suche vorbereitet für PDF-Index: \(query)" }
            Text(result).font(.caption).foregroundStyle(.secondary)
            Text("PDFKit ermöglicht später die Suche und Indexierung lokaler PDFs.").font(.caption).foregroundStyle(.secondary)
        }.navigationTitle("PDF-Suche")
    }
}

struct DamaReasoningSettingsView: View {
    @AppStorage("dama.deepReasoning") private var enabled = false
    @AppStorage("dama.codeChecks") private var codeChecks = true
    var body: some View {
        Form {
            Toggle("Tiefes Denken", isOn: $enabled)
            Toggle("Code automatisch prüfen", isOn: $codeChecks)
            Text("Der Modus steuert die gewünschte Antworttiefe. Er ersetzt keine System- oder Sicherheitsgrenzen.").font(.caption).foregroundStyle(.secondary)
        }.navigationTitle("Denken & Prüfen")
    }
}

struct DamaCodeCheckView: View {
    @State private var code = "func hello( { print(\"hi\") }"
    var warnings: [String] {
        var list: [String] = []
        if code.contains("func ") && !code.contains(")") { list.append("Möglicherweise fehlt eine schließende Klammer im Funktionskopf.") }
        if code.contains("{") && code.filter({ $0 == "{" }).count != code.filter({ $0 == "}" }).count { list.append("Anzahl der geschweiften Klammern stimmt nicht überein.") }
        if list.isEmpty { list.append("Keine einfachen Strukturfehler erkannt.") }
        return list
    }
    var body: some View {
        VStack(spacing: 12) {
            TextEditor(text: $code).font(.system(.body, design: .monospaced)).padding(6).overlay(RoundedRectangle(cornerRadius: 12).stroke(.secondary.opacity(0.2)))
            VStack(alignment: .leading) { ForEach(warnings, id: \.self) { Text("• \($0)") } }.frame(maxWidth: .infinity, alignment: .leading)
        }.padding().navigationTitle("Code prüfen")
    }
}

struct DamaDialectTranslationView: View {
    @State private var text = "Wie geht es dir?"
    @State private var dialect = "Deutsch"
    var body: some View {
        Form {
            TextEditor(text: $text).frame(minHeight: 130)
            Picker("Variante", selection: $dialect) { Text("Deutsch").tag("Deutsch"); Text("Schweizerdeutsch").tag("Schweizerdeutsch"); Text("Österreichisch").tag("Österreichisch") }
            Text("Dialekt-/Varietätenanpassung wird als eigener Übersetzungs-Skill an das Modell weitergegeben.").font(.caption).foregroundStyle(.secondary)
        }.navigationTitle("Dialekt")
    }
}

struct DamaSpeechCorrectionView: View {
    @State private var text = "ich habe gestern schule gehen"
    var body: some View {
        Form {
            TextEditor(text: $text).frame(minHeight: 140)
            Button("Korrigieren") { text = text.replacingOccurrences(of: "schule gehen", with: "zur Schule gegangen") }
            Text("Die vollständige Sprachkorrektur kann später direkt mit dem Schreib-Skill verbunden werden.").font(.caption).foregroundStyle(.secondary)
        }.navigationTitle("Sprachkorrektur")
    }
}

struct DamaVoiceAccessibilityView: View {
    @AppStorage("dama.voiceControl") private var enabled = false
    var body: some View {
        Form {
            Toggle("Dama-Sprachsteuerung", isOn: $enabled)
            Text("Beispiele: 'Neue Nachricht', 'Timer starten' oder 'Suche öffnen'. Dama verwendet dafür nur erlaubte App- und Systemaktionen.").font(.caption).foregroundStyle(.secondary)
        }.navigationTitle("Sprachsteuerung")
    }
}

struct DamaSketchView: View {
    @State private var points: [CGPoint] = []
    var body: some View {
        ZStack {
            Color.clear
            Path { path in
                guard let first = points.first else { return }
                path.move(to: first)
                for point in points.dropFirst() { path.addLine(to: point) }
            }.stroke(.primary, lineWidth: 3)
        }
        .contentShape(Rectangle())
        .gesture(DragGesture(minimumDistance: 0).onChanged { points.append($0.location) }.onEnded { _ in points.append(.init(x: -1, y: -1)) })
        .toolbar { ToolbarItem(placement: .topBarTrailing) { Button("Löschen") { points.removeAll() } } }
        .navigationTitle("Skizze")
    }
}

struct DamaLongThreadSummaryView: View {
    @State private var text = ""
    @State private var summary = ""
    var body: some View {
        VStack {
            TextEditor(text: $text).padding().overlay(RoundedRectangle(cornerRadius: 14).stroke(.secondary.opacity(0.2)))
            Button("Zusammenfassen") { summary = text.split(separator: "\n").prefix(5).joined(separator: "\n") }
                .buttonStyle(.borderedProminent)
            if !summary.isEmpty { DamaGlassCard { Text(summary).frame(maxWidth: .infinity, alignment: .leading) }.padding() }
        }.padding().navigationTitle("Thread-Zusammenfassung")
    }
}

struct DamaStyleOptimizerView: View {
    @State private var text = ""
    var body: some View {
        Form {
            TextEditor(text: $text).frame(minHeight: 180)
            Button("Stil optimieren") { text = text.trimmingCharacters(in: .whitespacesAndNewlines) }
            Text("Der Schreib-Skill kann Ton, Länge und Zielgruppe gezielt optimieren.").font(.caption).foregroundStyle(.secondary)
        }.navigationTitle("Stil optimieren")
    }
}

struct DamaTimelineView: View {
    let events = ["Start", "Bearbeitung", "Prüfung", "Fertig"]
    var body: some View {
        List { ForEach(Array(events.enumerated()), id: \.offset) { index, event in Label(event, systemImage: index == events.count - 1 ? "flag.checkered" : "circle") } }
            .navigationTitle("Timeline")
    }
}

struct DamaAudioBookmarksView: View {
    @State private var bookmarks: [TimeInterval] = []
    var body: some View {
        List {
            Button("Aktuelle Stelle markieren") { bookmarks.append(Date().timeIntervalSinceReferenceDate.truncatingRemainder(dividingBy: 3600)) }
            ForEach(Array(bookmarks.enumerated()), id: \.offset) { index, value in Text("Marke \(index + 1): \(Int(value)) s") }
        }.navigationTitle("Audio-Marken")
    }
}

struct DamaWhisperSettingsView: View {
    @AppStorage("dama.voice.whisper") private var whisper = false
    var body: some View { Form { Toggle("Flüstermodus", isOn: $whisper); Text("Die tatsächliche Lautstärke und Stimme werden durch die verwendete TTS-Engine bestimmt.").font(.caption).foregroundStyle(.secondary) }.navigationTitle("Flüstermodus") }
}

struct DamaCustomShortcutsView: View {
    @State private var shortcuts = ["Hey Dama", "Neuer Chat", "Suche öffnen"]
    var body: some View { List { ForEach(shortcuts, id: \.self) { Text($0) }.onDelete { shortcuts.remove(atOffsets: $0) }; Text("Weitere Kurzbefehle können über App Intents / Siri ergänzt werden.").font(.caption).foregroundStyle(.secondary) }.navigationTitle("Kurzbefehle") }
}

struct DamaMultiTabChatView: View {
    @State private var tabs = ["Chat 1"]
    var body: some View { List { ForEach(tabs, id: \.self) { Text($0) }; Button("Neuen Chat-Tab") { tabs.append("Chat \(tabs.count + 1)") } }.navigationTitle("Chat-Tabs") }
}

struct DamaRound4ToolsView: View {
    private let tools: [(String, String, AnyView)] = [
        ("Mathe", "function", AnyView(DamaMathSolverView())),
        ("Funktionsgraph", "chart.xyaxis.line", AnyView(DamaFunctionGraphView())),
        ("Modellvergleich", "square.stack.3d.up", AnyView(DamaModelComparisonView())),
        ("LaTeX", "function", AnyView(DamaLaTeXView())),
        ("Einheiten", "arrow.left.arrow.right", AnyView(DamaUnitsView())),
        ("Code-Diff", "arrow.left.arrow.right.square", AnyView(DamaCodeDiffView())),
        ("CSV", "tablecells", AnyView(DamaCSVEditorView())),
        ("Musiktheorie", "music.note", AnyView(DamaMusicTheoryView())),
        ("PDF-Suche", "doc.text.magnifyingglass", AnyView(DamaPDFSearchView())),
        ("Denken & Prüfen", "brain.head.profile", AnyView(DamaReasoningSettingsView())),
        ("Code prüfen", "checkmark.seal", AnyView(DamaCodeCheckView())),
        ("Dialekt", "character.bubble", AnyView(DamaDialectTranslationView())),
        ("Sprachkorrektur", "textformat.abc", AnyView(DamaSpeechCorrectionView())),
        ("Sprachsteuerung", "mic", AnyView(DamaVoiceAccessibilityView())),
        ("Skizze", "pencil.and.scribble", AnyView(DamaSketchView())),
        ("Thread-Zusammenfassung", "text.badge.checkmark", AnyView(DamaLongThreadSummaryView())),
        ("Stil optimieren", "wand.and.stars", AnyView(DamaStyleOptimizerView())),
        ("Timeline", "timeline.selection", AnyView(DamaTimelineView())),
        ("Audio-Marken", "bookmark", AnyView(DamaAudioBookmarksView())),
        ("Flüstermodus", "waveform", AnyView(DamaWhisperSettingsView())),
        ("Kurzbefehle", "command", AnyView(DamaCustomShortcutsView())),
        ("Chat-Tabs", "rectangle.split.3x1", AnyView(DamaMultiTabChatView()))
    ]
    var body: some View { List(tools, id: \.0) { item in NavigationLink { item.2 } label: { Label(item.0, systemImage: item.1) } }.navigationTitle("Dama Werkzeuge") }
}
